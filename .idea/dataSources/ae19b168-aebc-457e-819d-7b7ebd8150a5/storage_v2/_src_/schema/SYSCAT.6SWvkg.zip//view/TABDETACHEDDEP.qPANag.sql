create or replace view syscat.tabdetacheddep 
(tabschema, tabname, deptabschema, deptabname) 
as select 
bschema, bname, dschema, dname 
from sysibm.sysdependencies 
where btype = 'L'
