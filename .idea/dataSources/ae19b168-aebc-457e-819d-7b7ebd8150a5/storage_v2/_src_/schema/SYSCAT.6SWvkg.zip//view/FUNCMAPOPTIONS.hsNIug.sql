create or replace view syscat.funcmapoptions 
(function_mapping, option, setting) 
as select 
function_mapping, option, setting 
from sysibm.sysfuncmapoptions
