CREATE OR REPLACE view syscat.workloadauth 
(workloadid, workloadname, grantor, grantortype, grantee, granteetype, 
usageauth) 
as select 
w.workloadid, w.workloadname, a.grantor, a.grantortype, a.grantee, 
a.granteetype, a.usageauth 
from sysibm.sysworkloads w, sysibm.sysworkloadauth a 
where w.workloadid = a.workloadid
