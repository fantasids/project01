create or replace view syscat.workactionsets 
(actionsetname, actionsetid, workclasssetname, workclasssetid, create_time, 
alter_time, enabled, objecttype, objectname, objectid, remarks) 
as select 
a.actionsetname, a.actionsetid, b.workclasssetname, a.workclasssetid, 
a.create_time, a.alter_time, a.enabled, a.objecttype, 
case when a.objecttype = 'b' then c.serviceclassname 
when a.objecttype = 'w' then e.workloadname 
else null end, 
a.objectid, d.remarks 
from sysibm.sysworkactionsets as a left outer join sysibm.sysserviceclasses as c 
on c.serviceclassid = a.objectid 
left outer join sysibm.sysworkloads as e 
on e.workloadid = a.objectid 
left outer join sysibm.sysworkclasssets as b 
on a.workclasssetid = b.workclasssetid 
left outer join sysibm.syscomments as d 
on d.objectid = a.actionsetid and d.objecttype = 'a'
