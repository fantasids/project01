create or replace view syscat.tables 
(tabschema, tabname, owner, ownertype, type, status, 
base_tabschema, base_tabname, rowtypeschema, rowtypename, 
create_time, alter_time, invalidate_time, stats_time, colcount, 
tableid, tbspaceid, card, npages, mpages, fpages, overflow, tbspace, 
index_tbspace, long_tbspace, parents, children, selfrefs, 
keycolumns, keyindexid, keyunique, checkcount, 
datacapture, const_checked, pmap_id, partition_mode, 
log_attribute, pctfree, append_mode, refresh, 
refresh_time, locksize, volatile, row_format, 
property, statistics_profile, compression, rowcompmode, 
access_mode, clustered, active_blocks, droprule, maxfreespacesearch, 
avgcompressedrowsize, avgrowcompressionratio, avgrowsize, 
pctrowscompressed, logindexbuild, codepage, collationschema, 
collationname, collationschema_orderby, collationname_orderby, 
encoding_scheme, 
pctpagessaved, last_regen_time, secpolicyid, 
protectiongranularity, auditpolicyid, auditpolicyname, auditexceptionenabled, 
definer, oncommit, logged, onrollback, lastused, control, temporaltype, 
tableorg, extended_row_size, pctextendedrows, remarks) 
as select 
creator, name, definer, definertype, type, status, 
base_schema, base_name, rowtypeschema, rowtypename, 
ctime, alter_time, invalidate_time, stats_time, colcount, 
fid, tid, card, npages, mpages, fpages, overflow, tbspace, 
index_tbspace, long_tbspace, parents, children, selfrefs, 
keycolumns, keyobid, keyunique, checkcount, 
data_capture, const_checked, pmap_id, partition_mode, 
cast('0' as char(1)), pctfree, append_mode, refresh, 
refresh_time, locksize, volatile, cast('N' as char(1)), 
property, statistics_profile, compression, rowcompmode, 
access_mode, clustered, active_blocks, droprule, maxfreespacesearch, 
avgcompressedrowsize, avgrowcompressionratio, avgrowsize, 
pctrowscompressed, 
cast (case when logindexbuild='N' then 'OFF' 
when logindexbuild='Y' then 'ON' else NULL end as varchar(3)), 
codepage, 
coalesce((select c1.collationschema from sysibm.syscollations c1 
where t.collationid = c1.collationid), 'SYSIBM'), 
coalesce((select c1.collationname from sysibm.syscollations c1 
where t.collationid = c1.collationid), 
syscat.collationname(t.collationid)), 
coalesce((select c2.collationschema from sysibm.syscollations c2 
where t.collationid_orderby = c2.collationid), 'SYSIBM'), 
coalesce((select c2.collationname from sysibm.syscollations c2 
where t.collationid_orderby = c2.collationid), 
syscat.collationname(t.collationid_orderby)), 
encoding_scheme, pctpagessaved, last_regen_time, 
secpolicyid, protectiongranularity, auditpolicyid, 
case when t.auditpolicyid is null then null 
else (select auditpolicyname from sysibm.sysauditpolicies aud 
where t.auditpolicyid = aud.auditpolicyid) 
end, 
auditexceptionenabled, definer, oncommit, logged, onrollback, lastused, 
control, 
case 
when t.type <> 'T' OR (t.type='T' and t.definertype='S') then 
cast ('N' as char(1)) 
when EXISTS(select 1 from sysibm.sysperiods p where p.tabname = t.name 
and p.tabschema = t.creator and p.periodtype=2 ) and 
EXISTS(select 1 from sysibm.sysperiods p where p.tabname = t.name 
and p.tabschema = t.creator and p.periodtype=1 and 
p.historyfid <> 0 ) 
then  cast('B' as char(1)) 
when EXISTS(select 1 from sysibm.sysperiods p where p.tabname = t.name 
and p.tabschema = t.creator and p.periodtype=1 and 
p.historyfid <> 0 ) 
then cast('S' as char(1)) 
when EXISTS(select 1 from sysibm.sysperiods p where p.tabname = t.name 
and p.tabschema = t.creator and p.periodtype=2 ) 
then cast('A' as char(1)) 
else cast('N' as char(1)) 
end, 
case 
when type in ('A', 'N', 'V', 'W') then cast ('N' as char(1)) 
when substr(property,20,1) = 'Y' then cast ('C' as char(1)) 
else cast ('R' as char(1)) 
end, 
extended_row_size, pctextendedrows, 
remarks 
from sysibm.systables t
