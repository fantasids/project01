create or replace view syscat.indexdep 
(indschema, indname, btype, bschema, bmodulename, bname, bmoduleid, tabauth) 
as select 
dschema, dname, btype, bschema, m.modulename, bname, bmoduleid, tabauth 
from sysibm.sysdependencies 
left outer join sysibm.sysmodules m on bmoduleid=m.moduleid 
where dtype = 'I'
