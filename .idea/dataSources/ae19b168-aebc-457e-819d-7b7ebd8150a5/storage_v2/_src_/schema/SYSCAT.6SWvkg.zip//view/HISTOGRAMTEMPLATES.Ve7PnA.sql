create or replace view syscat.histogramtemplates 
(templateid, templatename, create_time, alter_time, 
numbins, remarks) 
as select 
a.templateid, a.templatename, a.create_time, a.alter_time, 
a.numbins, b.remarks 
from sysibm.syshistogramtemplates as a left outer join 
sysibm.syscomments as b 
on b.objectid = a.templateid and b.objecttype = 'h'
