create or replace view syscat.wrapoptions 
(wrapname, option, setting) 
as select 
wrapname, option, setting 
from sysibm.syswrapoptions
