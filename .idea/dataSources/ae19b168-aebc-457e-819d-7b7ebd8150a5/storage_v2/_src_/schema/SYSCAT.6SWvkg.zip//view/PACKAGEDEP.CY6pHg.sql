create or replace view syscat.packagedep 
(pkgschema, pkgname, binder, bindertype, btype, bschema, 
bmodulename, bname, bmoduleid, tabauth, varauth, unique_id, 
pkgversion) 
as select 
d.dcreator, d.dname, d.binder, d.bindertype, d.btype, d.bcreator, 
m.modulename, d.bname, d.bmoduleid, 
case when d.btype <> 'v' then d.tabauth else SMALLINT(0) end, 
case when d.btype = 'v' then d.tabauth else SMALLINT(0) end, d.dunique_id, 
(select p.pkgversion from sysibm.sysplan p 
where d.dcreator = p.creator 
and d.dname = p.name 
and d.dunique_id = p.unique_id) 
from sysibm.sysplandep d 
left outer join sysibm.sysmodules m on d.bmoduleid=m.moduleid 

