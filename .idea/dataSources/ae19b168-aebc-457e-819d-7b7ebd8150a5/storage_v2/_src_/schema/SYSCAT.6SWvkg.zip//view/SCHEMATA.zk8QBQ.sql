create or replace view syscat.schemata 
(schemaname, owner, ownertype, definer, definertype, create_time, 
auditpolicyid, auditpolicyname, auditexceptionenabled, datacapture, remarks) 
as select 
a.name, a.owner, a.ownertype, a.definer, a.definertype, a.create_time, 
a.auditpolicyid, 
case when a.auditpolicyid is null then null 
else (select auditpolicyname from sysibm.sysauditpolicies aud 
where a.auditpolicyid = aud.auditpolicyid) 
end, 
a.auditexceptionenabled, a.datacapture, a.remarks 
from sysibm.sysschemata as a
