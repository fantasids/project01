create or replace view syscat.colgroupcols 
(colgroupid, colname, tabschema, tabname, ordinal) 
as select 
colgroupid, colname, tabschema, tabname, ordinal 
from sysibm.syscolgroupscols
