create or replace view syscat.procedures 
(procschema, procname, specificname, procedure_id, 
definer, parm_count, parm_signature, origin, create_time, 
deterministic, fenced, nullcall, language, implementation, 
class, jar_id, parm_style, contains_sql, dbinfo, 
program_type, result_sets, valid, text_body_offset, text, 
remarks) 
as select 
a.routineschema, a.routinename, a.specificname, a.routine_id, 
a.definer, a.parm_count, a.parm_signature, a.origin, a.createdts, 
a.deterministic, a.fenced, a.null_call, a.language, a.implementation, 
(select pj.class from 
sysibm.sysroutineproperties as pj 
where pj.routine_id = a.routine_id), 
(SELECT pj.jar_id FROM 
SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id), 
a.parameter_style, a.sql_data_access, a.dbinfo, 
a.program_type, a.result_sets, a.valid, a.text_body_offset, a.text, 
a.remarks 
from sysibm.sysroutines as a 
where a.routinetype in ('P') 
and a.routineschema not in ('SYSIBMINTERNAL')
