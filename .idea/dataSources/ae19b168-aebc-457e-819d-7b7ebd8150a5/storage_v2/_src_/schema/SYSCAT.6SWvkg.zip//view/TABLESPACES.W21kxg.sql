create or replace view syscat.tablespaces 
(tbspace, owner, ownertype, create_time, tbspaceid, 
tbspacetype, datatype, extentsize, prefetchsize, overhead, 
transferrate, writeoverhead, writetransferrate, pagesize, dbpgname, 
bufferpoolid, drop_recovery, ngname, definer, datatag, sgname, 
sgid, effectiveprefetchsize, cachingtier, remarks) 
as select 
a.tbspace, a.definer, a.definertype, a.create_time, a.tbspaceid, 
case a.tbspacetype when 'F' then cast('D' as char(1)) else a.tbspacetype end, 
a.datatype, a.extentsize, a.prefetchsize, a.overhead, 
a.transferrate, a.writeoverhead, a.writetransferrate, a.pagesize, a.ngname, 
a.bufferpoolid, a.drop_recovery, a.ngname, a.definer, a.datatag, b.sgname, 
a.sgid, a.effectiveprefetchsize, 
cast( case 
when a.cachingtier = 0 then 'DISABLED' 
when a.cachingtier = -1 then 'INHERIT' 
else 'ENABLED' 
end as varchar(8)), 
a.remarks 
from sysibm.systablespaces a 
left outer join sysibm.sysstogroups b 
on a.sgid = b.sgid
