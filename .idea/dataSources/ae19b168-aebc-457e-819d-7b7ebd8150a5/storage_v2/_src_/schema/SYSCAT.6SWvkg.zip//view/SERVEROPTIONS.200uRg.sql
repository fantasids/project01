create or replace view syscat.serveroptions 
(wrapname, servername, servertype, serverversion, 
create_time, option, setting, serveroptionkey, remarks) 
as select 
wrapname, servername, servertype, serverversion, 
create_time, option, setting, serveroptionkey, remarks 
from sysibm.sysserveroptions
