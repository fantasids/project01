CREATE OR REPLACE view syscat.workclasssets 
(workclasssetname, workclasssetid, create_time, alter_time, remarks) 
as select 
a.workclasssetname, a.workclasssetid, a.create_time, a.alter_time, b.remarks 
from sysibm.sysworkclasssets as a left outer join sysibm.syscomments as b 
on b.objectid = a.workclasssetid and b.objecttype = 'e'
