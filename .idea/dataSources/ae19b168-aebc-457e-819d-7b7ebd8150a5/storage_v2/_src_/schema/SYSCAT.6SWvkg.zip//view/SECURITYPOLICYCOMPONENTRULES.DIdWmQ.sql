create or replace view syscat.securitypolicycomponentrules 
(secpolicyid, compid, ordinal, readaccessrulename, readaccessruletext, 
writeaccessrulename, writeaccessruletext) 
as (select secpolicyid, compid, ordinal, readaccessrulename, 
readaccessruletext, writeaccessrulename, writeaccessruletext 
from sysibm.syssecuritypolicycomponentrules)
