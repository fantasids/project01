create or replace view  syscat.variables 
(varschema, varmodulename, varname, varmoduleid, varid, 
owner, ownertype, create_time, last_regen_time, valid, published, 
typeschema, typemodulename, typename, typemoduleid, length, scale, 
typestringunits, stringunitslength, codepage, 
collationschema, collationname, collationschema_orderby, 
collationname_orderby, 
scope, default, qualifier, func_path, envstringunits, remarks, readonly, 
nulls) 
as select 
v.varschema, m.modulename, v.varname, v.varmoduleid, v.varid, 
v.owner, v.ownertype, v.create_time, v.last_regen_time, 
v.valid, v.published, d.schema, m1.modulename, d.name, d.typemoduleid, 
v.length, 
CASE WHEN (v.codepage=1208 or v.codepage=1200) and v.scale<>0 THEN CAST(0 as 
SMALLINT) 
ELSE v.scale END, 
CASE WHEN v.codepage=1208 and v.scale=0 THEN CAST('OCTETS' as VARCHAR(11)) 
WHEN v.codepage=1208 and v.scale=4 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
WHEN v.codepage=1200 and v.scale=0 THEN CAST('CODEUNITS16' as 
VARCHAR(11)) 
WHEN v.codepage=1200 and v.scale=2 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) END, 
CASE WHEN (v.codepage=1208 or v.codepage=1200) and v.scale=0 THEN v.length 
WHEN (v.codepage=1208 or v.codepage=1200) and v.scale<>0 THEN 
CAST(v.length/v.scale as INTEGER) 
ELSE CAST(NULL AS INTEGER) END, 
v.codepage, coalesce(c1.collationschema, 'SYSIBM'), 
coalesce(c1.collationname, syscat.collationname(v.collationid)), 
coalesce(c2.collationschema, 'SYSIBM'), 
coalesce(c2.collationname, syscat.collationname(v.collationid_orderby)), 
v.scope, v.default, v.qualifier, v.func_path, 
cast(case 
when v.stringunits = 'S' then 'SYSTEM' 
when v.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
c.remarks, v.readonly, v.nulls 
from 
sysibm.sysvariables as v 
left outer join sysibm.sysdatatypes as d on v.typeid = d.typeid 
left outer join sysibm.sysmodules m1 on d.typemoduleid = m1.moduleid 
left outer join sysibm.sysmodules m on v.varmoduleid = m.moduleid 
left outer join sysibm.syscomments as c 
on v.varid = c.objectid and c.objecttype = 'v' 
left outer join sysibm.syscollations as c1 
on v.collationid = c1.collationid 
left outer join sysibm.syscollations as c2 
on v.collationid_orderby = c2.collationid 
where NOT(d.schema = 'SYSPROC' AND d.name = 'DB2SQLSTATE') OR 
(d.schema IS NULL OR d.name IS NULL)
