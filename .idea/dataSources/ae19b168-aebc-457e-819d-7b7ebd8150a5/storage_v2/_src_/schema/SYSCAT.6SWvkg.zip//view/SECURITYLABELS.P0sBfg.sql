create or replace view syscat.securitylabels 
(seclabelname, seclabelid, secpolicyid, seclabel, create_time, remarks) 
as (select a.seclabelname, a.seclabelid, a.secpolicyid, 
CAST (a.seclabel_internal as SYSPROC.DB2SECURITYLABEL ), 
a.create_time, c.remarks 
from  sysibm.syssecuritylabels as a left outer join sysibm.syscomments as c 
on c.objecttype='l' and c.objectid=a.seclabelid)
