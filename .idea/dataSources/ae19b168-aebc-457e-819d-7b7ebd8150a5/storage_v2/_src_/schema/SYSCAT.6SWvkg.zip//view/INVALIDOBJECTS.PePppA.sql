create or replace view syscat.invalidobjects 
(objectschema, objectmodulename, objectname, routinename, objecttype, 
sqlcode, sqlstate, errormessage, linenumber, 
invalidate_time, last_regen_time) 
as select 
i.objectschema, m.modulename, i.objectname, 
case when i.objecttype = 'F' then r.routinename else null end, 
i.objecttype, i.sqlcode, i.sqlstate, 
cast(case when i.sqlcode is not null then 
case when i.sqlcode < 0 
then substring(SYSPROC.SQLERRM (concat('SQL', 
substring(varchar(i.sqlcode), 
2, octets)), i.sqlerrmc, x'FF', '', 1), 1, 4000, octets) 
else substring(SYSPROC.SQLERRM (concat('SQL', varchar(i.sqlcode)), 
i.sqlerrmc, 
x'FF', '', 1), 1, 4000, octets) end 
else null end as varchar(4000)), 
i.linenumber, i.invalidate_time, i.last_regen_time 
from sysibm.sysinvalidobjects i 
left outer join sysibm.sysroutines r on (i.objectname = r.specificname and 
i.objectschema = r.routineschema and (i.objectmoduleid = r.routinemoduleid or 
(i.objectmoduleid is NULL and r.routinemoduleid is NULL))) 
left outer join sysibm.sysmodules m on i.objectmoduleid = m.moduleid 

