create or replace view syscat.workloads 
(workloadid, workloadname, evaluationorder, create_time, alter_time, 
enabled, allowaccess, maxdegree, serviceclassname, parentserviceclassname, 
collectaggactdata, collectactdata, collectactpartition, 
collectdeadlock, collectlocktimeout, collectlockwait, lockwaitvalue, 
collectactmetrics, collectuowdataoptions, collectuowdata, externalname, 
sectionactualsoptions, collectagguowdata, remarks) 
as select 
w.workloadid, w.workloadname, w.evaluationorder, w.create_time, 
w.alter_time, w.enabled, w.allowaccess, w.maxdegree, s1.serviceclassname, 
s2.serviceclassname, w.collectaggactdata, w.collectactdata, 
w.collectactpartition, w.collectdeadlock, w.collectlocktimeout, 
w.collectlockwait, w.lockwaitvalue, w.collectactmetrics, 
w.collectuowdataoptions, 
CAST(case when substring(w.collectuowdataoptions,2,1,OCTETS)='Y' then 'P' 
else substring(w.collectuowdataoptions,1,1,OCTETS) 
end as CHAR(1)), 
w.externalname, w.sectionactualsoptions, w.collectagguowdata, c.remarks 
from sysibm.sysworkloads w left outer join sysibm.syscomments c 
on w.workloadid = c.objectid and c.objecttype = 'w' 
inner join sysibm.sysserviceclasses s1 
on s1.serviceclassid = w.serviceclassid 
left outer join sysibm.sysserviceclasses s2 
on s1.parentid = s2.serviceclassid
