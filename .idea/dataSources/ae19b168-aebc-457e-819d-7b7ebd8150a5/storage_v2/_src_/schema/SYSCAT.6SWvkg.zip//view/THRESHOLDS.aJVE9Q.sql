create or replace view syscat.thresholds 
(thresholdname, thresholdid, origin, thresholdclass, thresholdpredicate, 
thresholdpredicateid, domain, domainid, enforcement, queuing, maxvalue, 
datataglist, queuesize, overflowpercent, collectactdata, collectactpartition, 
execution, 
remapscid, violationrecordlogged, checkinterval, enabled, create_time, 
alter_time, remarks) 
as select 
t.thresholdname, t.thresholdid, t.origin, t.thresholdclass, 
t.thresholdpredicate, t.thresholdpredicateid, t.domain, t.domainid, 
t.enforcement, t.queuing, t.maxvalue, 
cast (case when t.thresholdpredicateid = 170 or t.thresholdpredicateid = 180 
then 
SYSIBMINTERNAL.WLM_FORMAT_DATA_TAG_LIST(t.maxvalue) 
else 
NULL 
end as VARCHAR(256)), 
t.queuesize, t.overflowpercent, t.collectactdata, 
t.collectactpartition, t.execution, t.remapscid, t.violationrecordlogged, 
t.checkinterval, t.enabled, t.create_time, t.alter_time, c.remarks 
from sysibm.systhresholds t 
left outer join sysibm.syscomments c 
on t.thresholdid = c.objectid and c.objecttype = 'f'
