create or replace view syscat.wrappers 
(wrapname, wraptype, wrapversion, library, remarks) 
as select 
wrapname, wraptype, wrapversion, library, remarks 
from sysibm.syswrappers
