create or replace view syscat.indexpartitions 
(indschema, indname, tabschema, tabname, iid, 
indpartitiontbspaceid, indpartitionobjectid, 
datapartitionid, indcard, nleaf, 
num_empty_leafs, numrids, numrids_deleted, 
fullkeycard, nlevels, clusterratio, clusterfactor, 
firstkeycard, first2keycard, first3keycard, 
first4keycard, avgleafkeysize, avgnleafkeysize, 
pctfree, page_fetch_pairs, sequential_pages, 
density, average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
average_random_pages, average_random_fetch_pages, stats_time, 
compression, pctpagessaved) 
as select 
indschema, indname, tabschema, tabname, iid, 
indpartitiontbspaceid, indpartitionobjectid, 
datapartitionid, indcard, nleaf, 
num_empty_leafs, numrids, numrids_deleted, 
fullkeycard, nlevels, clusterratio, clusterfactor, 
firstkeycard, first2keycard, first3keycard, 
first4keycard, avgleafkeysize, avgnleafkeysize, 
pctfree, page_fetch_pairs, sequential_pages, 
density, average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
average_random_pages, average_random_fetch_pages, stats_time, 
compression, pctpagessaved 
from sysibm.sysindexpartitions 
