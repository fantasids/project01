create or replace view syscat.colidentattributes 
(tabschema, tabname, colname, start, increment, 
minvalue, maxvalue, cycle, cache, order, nextcachefirstvalue, seqid) 
as select 
c.tbcreator, c.tbname, c.name, s.start, 
s.increment, s.minvalue, s.maxvalue, s.cycle, 
s.cache, s.order, 
cast(case when s.lastassignedval + s.increment > s.maxvalue 
and s.increment > 0 
then case when s.cycle = 'Y' then s.minvalue else null end 
when s.lastassignedval + s.increment < s.minvalue 
and s.increment < 0 
then case when s.cycle = 'Y' then s.maxvalue else null end 
else coalesce(s.lastassignedval + s.increment, s.start) end as decimal(31)), 
s.seqid 
from sysibm.syscolumns as c, sysibm.sysdependencies as d, 
sysibm.syssequences as s 
where c.tbcreator = d.dschema and 
c.tbname = d.dname and 
d.bname = s.seqname and 
d.bschema = s.seqschema and 
c.identity = 'Y' and 
d.dtype = 'T' and 
d.btype = 'Q' and 
s.seqtype = 'I'
