create or replace view syscat.useroptions 
(authid, authidtype, servername, option, setting) 
as select 
authid, authidtype, servername, option, 
case 
when option = 'REMOTE_PASSWORD' then '********' 
else setting 
end 
from sysibm.sysuseroptions
