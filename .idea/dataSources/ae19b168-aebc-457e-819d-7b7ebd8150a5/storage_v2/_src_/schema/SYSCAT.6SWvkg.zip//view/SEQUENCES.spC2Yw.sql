create or replace view syscat.sequences 
(seqschema, seqname, definer, definertype, owner, ownertype, seqid, seqtype, 
base_seqschema, base_seqname, 
increment, start, maxvalue, minvalue, nextcachefirstvalue, cycle, cache, 
order, datatypeid, sourcetypeid, create_time, alter_time, 
precision, origin, remarks) 
as select 
a.seqschema, a.seqname, a.definer, a.definertype, a.owner, a.ownertype, 
a.seqid, a.seqtype, a.base_seqschema, a.base_seqname, a.increment, a.start, 
a.maxvalue, a.minvalue, 
cast(case when a.lastassignedval + a.increment > a.maxvalue 
and a.increment > 0 
then case when a.cycle = 'Y' then a.minvalue else null end 
when a.lastassignedval + a.increment < a.minvalue 
and a.increment < 0 
then case when a.cycle = 'Y' then a.maxvalue else null end 
else coalesce(a.lastassignedval + a.increment, a.start) end as decimal(31)), 
a.cycle, a.cache, 
a.order, a.datatypeid, a.sourcetypeid, a.create_time, 
a.alter_time, a.precision, a.origin, b.remarks 
from sysibm.syssequences as a left outer join 
sysibm.syscomments as b 
on a.seqid = b.objectid and b.objecttype = 'Q'
