create or replace view syscat.sequenceauth 
(grantor, grantortype, grantee, granteetype, seqschema, seqname, 
alterauth, usageauth) 
as select 
a.grantor, a.grantortype, a.grantee, a.granteetype, b.seqschema, b.seqname, 
a.alterauth, a.usageauth 
from sysibm.syssequenceauth as a, sysibm.syssequences as b 
where a.seqid = b.seqid
