create or replace view syscat.taboptions 
(tabschema, tabname, option, setting) 
as select 
tabschema, tabname, option, setting 
from sysibm.systaboptions
