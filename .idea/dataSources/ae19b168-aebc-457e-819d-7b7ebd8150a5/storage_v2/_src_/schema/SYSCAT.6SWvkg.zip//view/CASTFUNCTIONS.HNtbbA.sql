create or replace view syscat.castfunctions 
(from_typeschema, from_typemodulename, from_typename, from_typemoduleid, 
to_typeschema, to_typemodulename, to_typename, to_typemoduleid, 
funcschema, funcmodulename, funcname, specificname, funcmoduleid, 
assign_function) 
as select 
p1.typeschema, m1.modulename, p1.typename, p1.typemoduleid, 
p2.typeschema, m2.modulename, p2.typename, p2.typemoduleid, 
f.routineschema, m.modulename, f.routinename, f.specificname, 
f.routinemoduleid, f.assign_function 
from 
(sysibm.sysroutines as f left outer join sysibm.sysmodules m on 
f.routinemoduleid = m.moduleid), 
(sysibm.sysroutineparms as p1 left outer join sysibm.sysmodules m1 on 
p1.typemoduleid = m1.moduleid), 
(sysibm.sysroutineparms as p2 left outer join sysibm.sysmodules m2 on 
p2.typemoduleid = m2.moduleid) 
where 
f.cast_function = 'Y' 
and f.routine_id = p1.routine_id 
and f.routine_id = p2.routine_id 
and f.routinetype in ('F', 'M') 
and f.routineschema not in ('SYSIBMINTERNAL') 
and p1.rowtype = 'P' 
and p1.ordinal = 1 
and p2.rowtype = 'C' 
and p2.ordinal = 0
