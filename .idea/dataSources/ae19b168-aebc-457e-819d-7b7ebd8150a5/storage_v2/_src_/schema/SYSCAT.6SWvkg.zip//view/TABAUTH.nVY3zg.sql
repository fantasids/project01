create or replace view syscat.tabauth 
(grantor, grantortype, grantee, granteetype, tabschema, tabname, 
controlauth, alterauth, deleteauth, indexauth, insertauth, 
refauth, selectauth, updateauth) 
as select 
grantor, grantortype, grantee, granteetype, tcreator, ttname, 
controlauth, alterauth, deleteauth, indexauth, insertauth, 
refauth, selectauth, updateauth 
from sysibm.systabauth 

