create or replace view syscat.tbspaceauth 
(grantor, grantortype, grantee, granteetype, tbspace, useauth) 
as select 
grantor, grantortype, grantee, granteetype, tbspace, useauth 
from sysibm.systbspaceauth
