create or replace view syscat.columns 
(tabschema, tabname, colname, colno, typeschema, 
typename, length, scale, typestringunits, stringunitslength, 
default, nulls, 
codepage, collationschema, collationname, logged, 
compact, colcard, high2key, low2key, avgcollen, 
keyseq, partkeyseq, nquantiles, nmostfreq, 
numnulls, target_typeschema, target_typename, 
scope_tabschema, scope_tabname, 
source_tabschema, source_tabname, 
dl_features, special_props, 
hidden, inline_length, pctinlined, identity, rowchangetimestamp, 
generated, text, compress, avgdistinctperpage, 
pagevarianceratio, sub_count, sub_delim_length, avgcollenchar, 
implicitvalue, seclabelname, rowbegin, rowend, transactionstartid, 
pctencoded, 
qualifier, func_path, remarks) 
as select 
c.tbcreator, c.tbname, c.name, c.colno, c.typeschema, 
c.typename, c.longlength, 
case when (c.composite_codepage=1208 or c.composite_codepage=1200) and 
c.scale<>0 then cast (0 as SMALLINT) 
else c.scale end, 
CASE WHEN c.composite_codepage=1208 and c.scale=0 THEN CAST('OCTETS' as 
VARCHAR(11)) 
WHEN c.composite_codepage=1208 and c.scale=4 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
WHEN c.composite_codepage=1200 and c.scale=0 THEN CAST('CODEUNITS16' as 
VARCHAR(11)) 
WHEN c.composite_codepage=1200 and c.scale=2 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) END, 
CASE WHEN (c.composite_codepage=1208 or c.composite_codepage=1200) and 
c.scale=0 THEN c.longlength 
WHEN (c.composite_codepage=1208 or c.composite_codepage=1200) and 
c.scale<>0 THEN CAST(c.longlength/c.scale as INTEGER) 
ELSE CAST(NULL AS INTEGER) END, 
c.default, c.nulls, 
c.composite_codepage, 
case when c.collationid is null then null 
else coalesce((select col.collationschema from sysibm.syscollations col 
where c.collationid = col.collationid), 
'SYSIBM') end, 
case when c.collationid is null then null 
else coalesce((select col.collationname from sysibm.syscollations col 
where c.collationid = col.collationid), 
syscat.collationname(c.collationid)) end, 
c.logged, c.compact, c.colcard, 
c.high2key, c.low2key, c.avgcollen, 
c.keyseq, c.partkeyseq, c.nquantiles, c.nmostfreq, 
c.numnulls, 
(select p.target_typeschema 
from sysibm.syscolproperties p 
where c.tbcreator = p.tabschema 
and c.tbname = p.tabname 
and c.name = p.colname), 
(select p.target_typename 
from sysibm.syscolproperties p 
where c.tbcreator = p.tabschema 
and c.tbname = p.tabname 
and c.name = p.colname), 
(select p.scope_tabschema 
from sysibm.syscolproperties p 
where c.tbcreator = p.tabschema 
and c.tbname = p.tabname 
and c.name = p.colname), 
(select p.scope_tabname 
from sysibm.syscolproperties p 
where c.tbcreator = p.tabschema 
and c.tbname = p.tabname 
and c.name = p.colname), 
c.source_tabschema, c.source_tabname, 
cast(coalesce(sysibm.deprecatedchar('-206', 'COLUMN', 
'SYSCAT.ATTRIBUTES.DL_FEATURES'), 
null) as char(10)), 
cast(case 
when c.coltype = 'REF' then 
(select p.special_props 
from sysibm.syscolproperties p 
where c.tbcreator = p.tabschema 
and c.tbname = p.tabname 
and c.name = p.colname) 
else null 
end as char(8)), 
c.hidden, c.inline_length, c.pctinlined, 
cast(case when c.identity = 'Y' then 'Y' 
else 'N' end as char(1)), 
cast(case when c.identity = 'T' then 'Y' 
else 'N' end as char(1)), 
c.generated, 
case 
when c.generated = ' ' then null 
else 
(select case 
when posstr(ch.text, ' =  ') = 0 
then ch.text 
else 'AS' concat 
substr(ch.text, 
posstr(ch.text, ' =  ') + 3) 
end 
from sysibm.syschecks ch, sysibm.syscolchecks cc 
where c.tbcreator = cc.tbcreator 
and c.tbname = cc.tbname 
and c.name = cc.colname 
and cc.usage = 'T' 
and cc.constname = ch.name 
and cc.tbcreator = ch.tbcreator 
and cc.tbname = ch.tbname) 
end, 
c.compress, c.avgdistinctperpage, c.pagevarianceratio, 
c.sub_count, c.sub_delim_length, c.avgcollenchar, c.implicitvalue, 
(select seclabelname 
from sysibm.syssecuritylabels where seclabelid = c.seclabelid), 
cast(case when c.identity = 'B' then 'Y' 
else 'N' 
end as char(1)), 
cast(case when c.identity = 'E' then 'Y' 
else 'N' 
end as char(1)), 
cast(case when c.identity = 'S' then 'Y' 
else 'N' 
end as char(1)), 
c.pctencoded, 
(select cast(setting as varchar(128)) 
from sysibm.syscoloptions 
where tabname = c.tbname 
and tabschema = c.tbcreator 
and colname = c.name 
and option = 'DEFAULT_QUALIFIER'), 
(select cast(setting as clob(2k)) 
from sysibm.syscoloptions 
where  tabname = c.tbname 
and tabschema = c.tbcreator 
and colname = c.name 
and option = 'DEFAULT_FUNC_PATH'), 
c.remarks 
from sysibm.syscolumns c 

