create or replace view syscat.auditpolicies 
(auditpolicyname, auditpolicyid, create_time, alter_time, 
auditstatus, contextstatus, validatestatus, checkingstatus, 
secmaintstatus, objmaintstatus, sysadminstatus, executestatus, 
executewithdata, errortype, remarks) 
as select 
a.auditpolicyname, a.auditpolicyid, a.create_time, 
a.alter_time, a.auditstatus, a.contextstatus, a.validatestatus, 
a.checkingstatus, a.secmaintstatus, a.objmaintstatus, 
a.sysadminstatus, a.executestatus, a.executewithdata, 
a.errortype, b.remarks 
from sysibm.sysauditpolicies as a left outer join sysibm.syscomments as b 
on a.auditpolicyid = b.objectid and b.objecttype='j'
