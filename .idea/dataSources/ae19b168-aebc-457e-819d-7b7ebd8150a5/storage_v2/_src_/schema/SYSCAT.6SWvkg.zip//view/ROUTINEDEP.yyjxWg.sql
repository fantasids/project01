create or replace view syscat.routinedep 
(routineschema, routinemodulename, specificname, routinemoduleid, 
btype, bschema, bmodulename, bname, bmoduleid, tabauth, routinename) 
as select 
dschema, md.modulename, dname, dmoduleid, 
btype, bschema, mb.modulename, bname, bmoduleid, tabauth, 
coalesce(sysibm.deprecatedchar('-206', 'COLUMN', 
'SYSCAT.ROUTINEDEP.ROUTINENAME'), dname) 
from sysibm.sysdependencies 
left outer join sysibm.sysmodules md on dmoduleid=md.moduleid 
left outer join sysibm.sysmodules mb on bmoduleid=mb.moduleid 
where dtype = 'F' 
and dschema not in ('SYSIBMINTERNAL')
