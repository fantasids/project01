create or replace view syscat.securitylabelcomponentelements 
(compid, elementvalue, elementvalueencoding,parentelementvalue) 
as( select compid, elementvalue, elementvalueencoding,parentelementvalue 
from sysibm.syssecuritylabelcomponentelements)
