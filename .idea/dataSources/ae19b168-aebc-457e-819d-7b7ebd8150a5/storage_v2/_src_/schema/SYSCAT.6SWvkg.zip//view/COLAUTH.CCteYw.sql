create or replace view syscat.colauth 
(grantor, grantortype, grantee, granteetype, tabschema, tabname, colname, 
colno, privtype, grantable) 
as select 
grantor, grantortype, grantee, granteetype, creator, tname, colname, 
colno, privtype, grantable 
from sysibm.syscolauth
