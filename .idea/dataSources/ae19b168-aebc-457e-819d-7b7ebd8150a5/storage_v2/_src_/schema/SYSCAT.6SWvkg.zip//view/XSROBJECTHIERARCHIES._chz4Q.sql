create or replace view syscat.xsrobjecthierarchies 
(objectid, componentid, htype, targetnamespace, schemalocation) 
as select 
o.xsrobjectid, o.xsrcomponentid, o.htype, 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where o.targetnamespaceid=stringid), 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where o.schemalocationid=stringid) 
from sysibm.sysxsrobjecthierarchies o
