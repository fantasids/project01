create or replace view syscat.nodegroupdef 
(ngname, nodenum, in_use) 
as select 
ngname, nodenum, in_use 
from sysibm.sysnodegroupdef
