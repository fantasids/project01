create or replace view syscat.rowfields 
(typeschema, typemodulename, typename, fieldname, fieldtypeschema, 
fieldtypemodulename, fieldtypename, ordinal, length, scale, 
typestringunits, stringunitslength, 
codepage, collationschema, collationname, nulls, qualifier, 
func_path, default, envstringunits) 
as select 
a.typeschema, m.modulename, a.typename, a.attr_name, a.attr_typeschema, 
ma.modulename, a.attr_typename, 
a.ordinal, a.length, 
CASE WHEN (a.codepage=1208 or a.codepage=1200) and a.scale<>0 THEN CAST(0 as 
SMALLINT) 
ELSE a.scale END, 
CASE WHEN a.codepage=1208 and a.scale=0 THEN CAST('OCTETS' as VARCHAR(11)) 
WHEN a.codepage=1208 and a.scale=4 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
WHEN a.codepage=1200 and a.scale=0 THEN CAST('CODEUNITS16' as 
VARCHAR(11)) 
WHEN a.codepage=1200 and a.scale=2 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) END, 
CASE WHEN (a.codepage=1208 or a.codepage=1200) and a.scale=0 THEN a.length 
WHEN (a.codepage=1208 or a.codepage=1200) and a.scale<>0 THEN 
CAST(a.length/a.scale as INTEGER) 
ELSE CAST(NULL AS INTEGER) END, 
a.codepage, 
case when a.collationid is null then null 
else coalesce(c.collationschema, 'SYSIBM') end, 
case when a.collationid is null then null 
else coalesce(c.collationname, syscat.collationname(a.collationid)) end, 
a.nulls, a.qualifier, a.func_path, a.default, 
cast(case 
when a.stringunits = 'S' then 'SYSTEM' 
when a.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)) 
from sysibm.sysattributes as a 
inner join sysibm.sysdatatypes as d on d.metatype='F' and 
a.typename = d.name and a.typeschema = d.schema and 
(a.typemoduleid = d.typemoduleid or a.typemoduleid is null and 
d.typemoduleid is null) 
left outer join sysibm.syscollations as c on a.collationid = c.collationid 
left outer join sysibm.sysmodules m  on a.typemoduleid=m.moduleid 
left outer join sysibm.sysmodules ma on a.attr_typemoduleid=ma.moduleid 

