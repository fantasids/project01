CREATE OR REPLACE view syscat.workloadconnattr 
(workloadid, workloadname, connattrtype, connattrvalue) 
as select 
w.workloadid, w.workloadname, 
cast (case c.connattrid 
when 1 then 'APPLNAME' 
when 2 then 'SYSTEM_USER' 
when 3 then 'SESSION_USER' 
when 4 then 'SESSION_USER GROUP' 
when 5 then 'SESSION_USER ROLE' 
when 6 then 'CURRENT CLIENT_USERID' 
when 7 then 'CURRENT CLIENT_APPLNAME' 
when 8 then 'CURRENT CLIENT_WRKSTNNAME' 
when 9 then 'CURRENT CLIENT_ACCTNG' 
when 10 then 'ADDRESS' 
else 'UNKNOWN' 
end as varchar(30)), 
c.connattrvalue 
from sysibm.sysworkloads w, sysibm.sysworkloadconnattr c 
where w.workloadid = c.workloadid
