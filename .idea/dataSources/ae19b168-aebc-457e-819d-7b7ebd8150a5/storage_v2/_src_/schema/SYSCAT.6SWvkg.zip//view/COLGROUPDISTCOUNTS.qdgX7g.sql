create or replace view syscat.colgroupdistcounts 
(colgroupid, type, seqno, valcount, distcount) 
as select 
colgroupid, type, seqno, valcount, distcount 
from sysibm.syscolgroupdistcounts
