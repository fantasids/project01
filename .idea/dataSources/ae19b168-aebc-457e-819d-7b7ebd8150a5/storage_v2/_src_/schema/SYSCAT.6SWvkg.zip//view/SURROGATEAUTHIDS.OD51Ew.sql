create or replace view syscat.surrogateauthids 
(grantor, trustedid,  trustedidtype, surrogateauthid, 
surrogateauthidtype, authenticate, contextrole, grant_time) 
as (select grantor, trustedid,  trustedidtype, surrogateauthid, 
surrogateauthidtype, authenticate, contextrole, grant_time 
from sysibm.syssurrogateauthids)
