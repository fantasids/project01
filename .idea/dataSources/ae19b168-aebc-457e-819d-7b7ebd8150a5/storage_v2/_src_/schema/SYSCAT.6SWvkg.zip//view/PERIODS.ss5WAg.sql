create or replace view syscat.periods 
(periodname, tabschema, tabname, begincolname, endcolname, 
periodtype, historytabschema, historytabname) 
as select 
p.periodname, p.tabschema, p.tabname, 
(select c.name from sysibm.syscolumns c 
where c.tbname = p.tabname 
and c.tbcreator = p.tabschema 
and c.colno = p.begincolno), 
(select c.name from sysibm.syscolumns c 
where c.tbname = p.tabname 
and c.tbcreator = p.tabschema 
and c.colno = p.endcolno), 
case when p.periodtype = 1 then cast('S' as char(1)) 
else cast('A' as char(1)) 
end, 
t.creator, t.name 
from sysibm.sysperiods as p 
left outer join sysibm.systables as t 
on p.historytid = t.tid and p.historyfid = t.fid
