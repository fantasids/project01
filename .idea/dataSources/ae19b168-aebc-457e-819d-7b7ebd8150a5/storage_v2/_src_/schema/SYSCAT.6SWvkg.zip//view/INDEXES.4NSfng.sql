create or replace view syscat.indexes 
(indschema, indname, owner, ownertype, tabschema, tabname, colnames, 
uniquerule, made_unique, colcount, 
unique_colcount, indextype, entrytype, pctfree, 
iid, nleaf, nlevels, 
firstkeycard, first2keycard, first3keycard, first4keycard, 
fullkeycard, clusterratio, clusterfactor, sequential_pages, 
density, user_defined, system_required, create_time, 
stats_time, page_fetch_pairs, minpctused, reverse_scans, 
internal_format, compression, 
ieschema, iename, iearguments, index_objectid, 
numrids, numrids_deleted, num_empty_leafs, 
average_random_fetch_pages, average_random_pages, 
average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
tbspaceid, level2pctfree, pagesplit, 
avgpartition_clusterratio, avgpartition_clusterfactor, 
avgpartition_page_fetch_pairs, pctpagessaved, 
datapartition_clusterfactor, indcard, avgleafkeysize, 
avgnleafkeysize, os_ptr_size, 
collectstatistcs, definer, lastused, 
periodname, periodpolicy, made_withoutoverlaps, 
envstringunits, nullkeys, func_path, viewschema, viewname, remarks) 
as select 
creator, name, definer, definertype, tbcreator, tbname, 
coalesce(sysibm.deprecatedchar('-206', 'COLUMN', 
'SYSCAT.INDEXES.COLNAMES'), 
colnames), 
uniquerule, made_unique, colcount, 
unique_colcount,indextype, entrytype, pctfree, 
iid, nleaf, nlevels, 
firstkeycard, first2keycard, first3keycard, first4keycard, 
fullkeycard, clusterratio, clusterfactor, sequential_pages, 
density, user_defined, system_required, create_time, 
stats_time, page_fetch_pairs, minpctused, reverse_scans, 
internal_format, compression, 
ieschema, iename, iearguments, index_objectid, 
numrids, numrids_deleted, num_empty_leafs, 
average_random_fetch_pages, average_random_pages, 
average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
tbspaceid, level2pctfree, pagesplit, 
avgpartition_clusterratio, avgpartition_clusterfactor, 
avgpartition_page_fetch_pairs, pctpagessaved, 
datapartition_clusterfactor, indcard, avgleafkeysize, 
avgnleafkeysize, os_ptr_size, 
collectstatistics, definer, lastused, 
periodname, periodpolicy, made_withoutoverlaps, 
cast(case 
when stringunits = 'S' then 'SYSTEM' 
when stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
nullkeys, func_path, 
(select d.bschema 
from sysibm.sysdependencies d, 
sysibm.systables t 
where i.func_path is not null and 
d.btype = 'V' and 
d.bname = t.name and 
d.bschema = t.creator and 
d.dtype = 'I' and 
d.dname = i.name and 
d.dschema = i.creator and 
substr(t.property, 19, 1) = 'Y' 
), 
(select d.bname 
from sysibm.sysdependencies d, 
sysibm.systables t 
where i.func_path is not null and 
d.btype = 'V' and 
d.bname = t.name and 
d.bschema = t.creator and 
d.dtype = 'I' and 
d.dname = i.name and 
d.dschema = i.creator and 
substr(t.property, 19, 1) = 'Y'), 
remarks 
from sysibm.sysindexes i
