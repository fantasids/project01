create or replace view syscat.keycoluse 
(constname, tabschema, tabname, colname, colseq) 
as select 
constname, tbcreator, tbname, colname, colseq 
from sysibm.syskeycoluse
