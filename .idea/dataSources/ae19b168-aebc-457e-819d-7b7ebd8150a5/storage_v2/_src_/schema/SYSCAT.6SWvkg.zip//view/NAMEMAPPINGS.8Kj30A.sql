create or replace view syscat.namemappings 
(type, logical_schema, logical_name, logical_colname, 
impl_schema, impl_name, impl_colname) 
as select 
type, logical_schema, logical_name, logical_colname, 
impl_schema, impl_name, impl_colname 
from sysibm.sysnamemappings
