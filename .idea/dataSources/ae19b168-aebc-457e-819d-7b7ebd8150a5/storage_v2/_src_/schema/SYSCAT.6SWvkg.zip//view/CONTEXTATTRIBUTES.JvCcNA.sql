create or replace view syscat.contextattributes 
(contextname, attr_name, attr_value, attr_options) 
as  select 
b.contextname, a.attr_name, a.attr_value, a.attr_options 
from sysibm.syscontextattributes a, sysibm.syscontexts b 
where a.contextid = b.contextid
