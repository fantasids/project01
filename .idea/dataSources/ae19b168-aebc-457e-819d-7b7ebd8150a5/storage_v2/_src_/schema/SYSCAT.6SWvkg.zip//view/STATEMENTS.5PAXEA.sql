create or replace view syscat.statements 
(pkgschema, pkgname, stmtno, sectno, seqno, text, unique_id, version) 
as select 
s.plcreator, s.plname, 
s.stmtno, s.sectno, 1, s.text, s.unique_id, 
(select p.pkgversion from sysibm.sysplan p 
where s.plcreator = p.creator 
and s.plname = p.name 
and s.unique_id = p.unique_id) 
from sysibm.sysstmt s
