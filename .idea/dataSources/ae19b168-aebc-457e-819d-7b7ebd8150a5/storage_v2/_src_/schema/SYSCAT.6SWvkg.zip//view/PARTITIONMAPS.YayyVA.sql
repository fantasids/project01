create or replace view syscat.partitionmaps 
(pmap_id, partitionmap) 
as select 
pmap_id, partitionmap 
from sysibm.syspartitionmaps 
where pmap_id <> -2
