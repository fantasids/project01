create or replace view syscat.xdbmapshredtrees 
(objectid, objectschema, objectname, schemagraphid, 
shredtreeid, mappingdescription) 
as select 
o.xsrobjectid, o.xsrobjectschema, o.xsrobjectname, m.schemagraphid, 
m.shredtreeid, m.mappingdescription 
from sysibm.sysxdbmapshredtrees m, 
sysibm.sysxsrobjects o 
where o.xsrobjectid=m.xsrobjectid
