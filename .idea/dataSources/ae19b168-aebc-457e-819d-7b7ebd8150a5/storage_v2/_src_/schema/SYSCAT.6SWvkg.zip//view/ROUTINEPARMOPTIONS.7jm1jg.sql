create or replace view syscat.routineparmoptions 
(routineschema, routinename, specificname, ordinal, option, setting) 
as select 
a.routineschema, a.routinename, a.specificname, b.ordinal, b.option, b.setting 
from sysibm.sysroutines a , sysibm.sysroutineparmoptions b 
where a.routine_id = b.routineid 
and a.routineschema not in ('SYSIBMINTERNAL')
