create or replace view syscat.passthruauth 
(grantor, grantortype, grantee, granteetype, servername) 
as select 
grantor, grantortype, grantee, granteetype, servername 
from sysibm.syspassthruauth
