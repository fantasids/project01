create or replace view syscat.tabconst 
(constname, tabschema, tabname, owner, ownertype, type, 
enforced, trusted, checkexistingdata, enablequeryopt, definer, 
periodname, periodpolicy, remarks) 
as select 
name, tbcreator, tbname, definer, definertype, constraintyp, 
enforced, trusted, checkexistingdata, enablequeryopt, definer, 
periodname, periodpolicy, remarks 
from sysibm.systabconst
