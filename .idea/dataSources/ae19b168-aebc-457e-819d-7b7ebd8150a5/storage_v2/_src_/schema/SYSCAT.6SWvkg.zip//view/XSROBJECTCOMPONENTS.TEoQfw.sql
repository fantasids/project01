create or replace view syscat.xsrobjectcomponents 
(objectid, objectschema, objectname,componentid,targetnamespace, 
schemalocation, component, create_time, status) 
as select 
o.xsrobjectid, o.xsrobjectschema, o.xsrobjectname, c.xsrcomponentid, 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where c.targetnamespaceid=stringid), 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where c.schemalocationid=stringid), 
c.component, c.create_time, c.status 
from sysibm.sysxsrobjects o, 
sysibm.sysxsrobjectcomponents c, 
sysibm.sysxsrobjecthierarchies h 
where o.xsrobjectid=h.xsrobjectid 
and c.xsrcomponentid=h.xsrcomponentid 
and (h.htype='P' or h.htype='D')
