create or replace view syscat.scpreftbspaces 
(serviceclassname, parentserviceclassname, tbspace, serviceclassid, 
parentserviceclassid, tbspaceid, datatype) 
as select 
b.serviceclassname, d.serviceclassname, c.tbspace, a.serviceclassid, 
d.serviceclassid, a.tbspaceid, c.datatype 
from (sysibm.sysscpreftbspaces as a left outer join 
sysibm.sysserviceclasses as b on a.serviceclassid = b.serviceclassid 
left outer join sysibm.systablespaces as c on a.tbspaceid = c.tbspaceid 
left outer join sysibm.sysserviceclasses as d on 
b.parentid = d.serviceclassid)
