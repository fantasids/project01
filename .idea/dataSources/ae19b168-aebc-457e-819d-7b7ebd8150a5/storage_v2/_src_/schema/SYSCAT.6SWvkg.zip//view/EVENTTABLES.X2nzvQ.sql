create or replace view syscat.eventtables 
(evmonname, logical_group, tabschema, tabname, pctdeactivate, taboptions) 
as select 
evmonname, logical_group, tabschema, tabname, pctdeactivate, taboptions 
from sysibm.syseventtables
