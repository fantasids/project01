create or replace view syscat.coloptions 
(tabschema, tabname, colname, option, setting) 
as select 
tabschema, tabname, colname, option, setting 
from sysibm.syscoloptions 
where option not in ('DEFAULT_QUALIFIER', 'DEFAULT_FUNC_PATH')
