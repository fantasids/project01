create or replace view syscat.indexextensions 
(ieschema, iename, owner, ownertype, create_time, keygenfuncschema, 
keygenfuncname, keygenspecificname, text, definer, remarks) 
as select 
ieschema, iename, definer, definertype, create_time, ktfuncschema, 
ktfuncname, ktspecificname, text, definer, remarks 
from sysibm.sysindexextensions
