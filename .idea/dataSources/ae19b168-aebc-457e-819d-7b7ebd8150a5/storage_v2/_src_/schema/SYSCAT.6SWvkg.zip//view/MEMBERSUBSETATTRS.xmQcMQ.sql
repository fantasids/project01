create or replace view syscat.membersubsetattrs 
(subsetid, attrid, attrvalue) 
as select 
a.subsetid, a.attrid, a.attrvalue 
from sysibm.sysmembersubsetattrs as a 
