create or replace view syscat.datapartitions 
(datapartitionname, tabschema, tabname, datapartitionid, 
tbspaceid, partitionobjectid, long_tbspaceid, 
access_mode, status, seqno, 
lowinclusive, lowvalue, highinclusive, highvalue, 
card, overflow, npages, fpages, active_blocks, 
index_tbspaceid, avgrowsize, pctrowscompressed, 
pctpagesaved, avgcompressedrowsize, avgrowcompressionratio, 
stats_time, lastused) 
as select 
datapartitionname, tabschema, tabname, datapartitionid, 
tbspaceid, partitionobjectid, long_tbspaceid, 
access_mode, status, seqno, 
lowinclusive, lowvalue, highinclusive, highvalue, 
card, overflow, npages, fpages, active_blocks, 
index_tbspaceid, avgrowsize, pctrowscompressed, 
pctpagesaved, avgcompressedrowsize, avgrowcompressionratio, 
stats_time, lastused 
from sysibm.sysdatapartitions
