create or replace view syscat.membersubsetmembers 
(subsetid, member) 
as select 
m.subsetid, m.member 
from sysibm.sysmembersubsetmembers as m 
