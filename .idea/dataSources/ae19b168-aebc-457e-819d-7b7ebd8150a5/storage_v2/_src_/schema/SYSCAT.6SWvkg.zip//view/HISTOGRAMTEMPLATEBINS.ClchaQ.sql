create or replace view syscat.histogramtemplatebins 
(templatename, templateid, binid, binuppervalue) 
as select 
a.templatename, b.templateid, b.binid, b.binuppervalue 
from sysibm.syshistogramtemplatebins as b left outer join 
sysibm.syshistogramtemplates as a 
on b.templateid = a.templateid
