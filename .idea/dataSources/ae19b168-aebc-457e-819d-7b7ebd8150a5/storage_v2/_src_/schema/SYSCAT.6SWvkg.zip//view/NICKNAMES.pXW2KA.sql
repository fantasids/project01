create or replace view syscat.nicknames 
(tabschema, tabname, owner, ownertype, status, 
create_time, stats_time, colcount, tableid, 
tbspaceid, card, npages, fpages, overflow, 
parents, children, selfrefs, 
keycolumns, keyindexid, keyunique, checkcount, 
datacapture, const_checked,  partition_mode, 
statistics_profile, 
access_mode, 
codepage , 
remote_table, remote_schema, servername, remote_type, 
cachingallowed, definer, remarks ) 
as select 
creator, name, definer, definertype, status, 
ctime, stats_time, colcount, fid, 
tid, card, npages, fpages, overflow, 
parents, children, selfrefs, 
keycolumns, keyobid, keyunique, checkcount, 
data_capture, const_checked, partition_mode, 
statistics_profile, 
access_mode, codepage, 
(select cast(setting as varchar(128)) from sysibm.systaboptions 
where name = tabname and creator = tabschema and option='REMOTE_TABLE'), 
(select cast(setting as varchar(128)) from sysibm.systaboptions 
where  name = tabname and creator = tabschema and option='REMOTE_SCHEMA') , 
(select cast(setting as varchar(128)) from sysibm.systaboptions 
where name = tabname and creator = tabschema and option='SERVER'), 
(select cast(setting as char(1)) from sysibm.systaboptions 
where name = tabname and creator = tabschema and option='REMOTE_TYPE'), 
CASE substr(property,11,1)  WHEN 'Y' THEN 'N' ELSE 'Y' END, 
definer, remarks 
from sysibm.systables  where type='N'
