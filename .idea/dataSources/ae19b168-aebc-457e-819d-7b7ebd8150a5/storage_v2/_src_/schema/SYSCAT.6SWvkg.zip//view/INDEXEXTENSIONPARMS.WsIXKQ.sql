create or replace view syscat.indexextensionparms 
(ieschema, iename, ordinal, parmname, typeschema, typename, 
length, scale, parmtype, codepage, collationschema, collationname) 
as select 
i.ieschema, i.iename, i.ordinal, i.parmname, i.typeschema, i.typename, 
i.length, i.scale, i.parmtype, i.codepage, 
case when i.collationid is null then null 
else coalesce(c.collationschema, 'SYSIBM') end, 
case when i.collationid is null then null 
else coalesce(c.collationname, syscat.collationname(i.collationid)) end 
from sysibm.sysindexextensionparms as i 
left outer join sysibm.syscollations as c on i.collationid = c.collationid
