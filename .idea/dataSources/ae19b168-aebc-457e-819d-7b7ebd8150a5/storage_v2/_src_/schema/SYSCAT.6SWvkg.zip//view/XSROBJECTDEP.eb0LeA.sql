create or replace view syscat.xsrobjectdep 
(objectid, objectschema, objectname, btype, 
bschema, bmodulename, bname, bmoduleid, tabauth) 
as select 
x.xsrobjectid, d.dschema, d.dname, d.btype, 
d.bschema, m.modulename, d.bname, d.bmoduleid, d.tabauth 
from sysibm.sysdependencies d 
left outer join sysibm.sysmodules m on d.bmoduleid=m.moduleid, 
sysibm.sysxsrobjects x 
where d.dtype = 'Z' and 
x.xsrobjectname=d.dname and x.xsrobjectschema=d.dschema
