create or replace view syscat.bufferpoolnodes 
(bufferpoolid, nodenum, npages) 
as select 
bufferpoolid, nodenum, npages 
from sysibm.sysbufferpoolnodes
