create or replace view syscat.xdbmapgraphs 
(objectid, objectschema, objectname, schemagraphid, 
namespace, rootelement) 
as select 
o.xsrobjectid, o.xsrobjectschema, o.xsrobjectname, m.schemagraphid, 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where m.namespaceid=stringid), 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where m.rootelementid=stringid) 
from sysibm.sysxdbmapgraphs m, 
sysibm.sysxsrobjects o 
where o.xsrobjectid=m.xsrobjectid
