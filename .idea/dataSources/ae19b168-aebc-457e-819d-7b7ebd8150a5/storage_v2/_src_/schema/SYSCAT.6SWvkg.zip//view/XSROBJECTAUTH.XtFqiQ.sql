create or replace view syscat.xsrobjectauth 
(grantor, grantortype, grantee, granteetype, objectid, usageauth) 
as select 
grantor, grantortype, grantee, granteetype, xsrobjectid, usageauth 
from sysibm.sysxsrobjectauth
