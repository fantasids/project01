create or replace view syscat.usagelists 
(usagelistschema, usagelistname, usagelistid, objectschema, 
objectname, objecttype, status, maxlistsize, whenfull, 
autostart, activeduration, remarks) 
as select 
a.usagelistschema, a.usagelistname, a.usagelistid, a.objectschema, 
a.objectname, a.objecttype, a.status, a.maxlistsize, a.whenfull, 
a.autostart, a.activeduration, b.remarks 
from sysibm.sysusagelists as a left outer join sysibm.syscomments as b 
on a.usagelistid = b.objectid and b.objecttype = '3'
