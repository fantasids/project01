create or replace view syscat.roleauth 
(grantor, grantortype, grantee, granteetype, rolename, roleid, admin) 
as select 
grantor, grantortype, grantee, granteetype, rolename, roleid, admin 
from sysibm.sysroleauth 
where rolename not LIKE 'SYSROLE%'
