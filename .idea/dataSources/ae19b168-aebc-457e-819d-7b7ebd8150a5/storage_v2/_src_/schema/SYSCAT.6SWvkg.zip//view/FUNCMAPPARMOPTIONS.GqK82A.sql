create or replace view syscat.funcmapparmoptions 
(function_mapping, ordinal, location, option, setting) 
as select 
function_mapping, ordinal, location, option, setting 
from sysibm.sysfuncmapparmoptions
