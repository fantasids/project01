create or replace view syscat.routines 
(routineschema, routinemodulename, routinename, routinetype, 
owner, ownertype, 
specificname, routineid, routinemoduleid, return_typeschema, 
return_typemodule, return_typename, origin, functiontype, 
parm_count, language, dialect, sourceschema, sourcemodulename, sourcespecific, published, 
deterministic, external_action, nullcall, cast_function, 
assign_function, scratchpad, scratchpad_length, 
finalcall, parallel, parameter_style, fenced, 
sql_data_access, dbinfo, programtype, commit_on_return, autonomous, 
result_sets, spec_reg, federated, threadsafe, valid, 
moduleroutineimplemented, methodimplemented, methodeffect, type_preserving, 
with_func_access, overridden_methodid, subject_typeschema, 
subject_typename, class, jar_id, jarschema, jar_signature, 
create_time, alter_time, func_path, qualifier, 
ios_per_invoc, insts_per_invoc, ios_per_argbyte, 
insts_per_argbyte, percent_argbytes, initial_ios, 
initial_insts, cardinality, selectivity, result_cols, 
implementation, lib_id, text_body_offset, text, newsavepointlevel, 
debug_mode, trace_level, diagnostic_level, checkout_userid, 
precompile_options, compile_options, execution_control, 
codepage, collationschema, 
collationname, collationschema_orderby, collationname_orderby, 
encoding_scheme, last_regen_time, inheritlockrequest, 
definer, secure, envstringunits, remarks) 
as select 
a.routineschema, m.modulename, a.routinename, a.routinetype, 
a.definer, a.definertype, 
a.specificname, a.routine_id, a.routinemoduleid, 
( select schema from sysibm.sysdatatypes 
where return_type = typeid ), 
( select m1.modulename 
from sysibm.sysdatatypes d left outer join sysibm.sysmodules m1 
on d.typemoduleid = m1.moduleid 
where a.return_type = d.typeid), 
( select name from sysibm.sysdatatypes 
where return_type = typeid ), 
a.origin, a.function_type, 
a.parm_count, a.language, 
CAST (CASE 
WHEN a.dialect = '1' THEN 'DB2 SQL PL' 
WHEN a.dialect = '2' THEN 'PL/SQL' 
ELSE ' ' 
END AS VARCHAR(10)), 
a.sourceschema, 
case when a.origin='U' and a.sourceschema<>'SYSIBM' then 
(select sm.modulename from sysibm.sysmodules sm 
where sm.moduleid= 
(select sr.routinemoduleid from sysibm.sysroutines sr 
where sr.routine_id=a.sourceroutineid)) 
else null end, 
a.sourcespecific, a.published, 
a.deterministic, a.external_action, a.null_call, a.cast_function, 
a.assign_function, a.scratchpad, a.scratchpad_length, 
a.final_call, a.parallel, a.parameter_style, a.fenced, 
a.sql_data_access, a.dbinfo, a.program_type, a.commit_on_return, a.autonomous, 
a.result_sets, a.spec_reg, a.federated, a.threadsafe, a.valid, 
cast(case when a.routinemoduleid is not null then a.methodimplemented 
else ' ' end as char(1)), 
cast(case when a.routinemoduleid is null then a.methodimplemented 
else ' ' end as char(1)), 
a.methodeffect, a.type_preserving, 
a.with_func_access, a.overridden_methodid, a.subject_typeschema, 
a.subject_typename, b.class, b.jar_id, b.jarschema, b.jar_signature, 
a.createdts, a.alteredts, a.func_path, a.qualifier, a.ios_per_invoc, 
a.insts_per_invoc, a.ios_per_argbyte, a.insts_per_argbyte, 
a.percent_argbytes, a.initial_ios, a.initial_insts, a.cardinality, 
a.selectivity, a.result_cols, a.implementation, a.lib_id, 
a.text_body_offset, a.text, a.newsavepointlevel, 
cast (case 
when a.debug_mode = '0' then 'DISALLOW' 
when a.debug_mode = '1' then 'ALLOW' 
when a.debug_mode = 'N' then 'DISABLE' 
else a.debug_mode end as varchar(8)), 
cast (case when c.trace_level is null then '0' 
else c.trace_level end as varchar(1)), 
cast (case when c.diagnostic_level is null then '0' 
else c.diagnostic_level end as varchar(1)), 
c.checkout_userid, c.precompile_options, 
c.compile_options, a.execution_control, a.codepage, 
coalesce(c1.collationschema, 'SYSIBM'), 
coalesce(c1.collationname, syscat.collationname(a.collationid)), 
coalesce(c2.collationschema, 'SYSIBM'), 
coalesce(c2.collationname, syscat.collationname(a.collationid_orderby)), 
a.encoding_scheme, a.last_regen_time, a.inheritlockrequest, 
a.definer, a.secure, 
cast(case 
when a.stringunits = 'S' then 'SYSTEM' 
when a.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
a.remarks 
from (sysibm.sysroutines as a 
left outer join sysibm.sysroutineproperties as b 
on a.routine_id = b.routine_id ) 
left outer join sysibm.syscodeproperties as c 
on a.routine_id = c.object_id 
and c.object_type = 'F' 
left outer join sysibm.syscollations as c1 
on a.collationid = c1.collationid 
left outer join sysibm.syscollations as c2 
on a.collationid_orderby = c2.collationid 
left outer join sysibm.sysmodules m 
on a.routinemoduleid = m.moduleid 
where a.routineschema not in ('SYSIBMINTERNAL') 

