create or replace view syscat.typemappings 
(type_mapping, mappingdirection, 
typeschema, typename, typeid, sourcetypeid, owner, ownertype, 
length, scale, lower_len, upper_len, 
lower_scale, upper_scale, s_opr_p, bit_data, 
wrapname, servername, servertype, serverversion, 
remote_typeschema, remote_typename, remote_meta_type, 
remote_lower_len, remote_upper_len, remote_lower_scale, remote_upper_scale, 
remote_s_opr_p, remote_bit_data, user_defined, create_time, definer, remarks) 
as select 
type_mapping, mappingdirection, 
typeschema, typename, typeid, sourcetypeid, definer, definertype, 
upper_len, upper_scale, lower_len, upper_len, 
lower_scale, upper_scale, s_opr_p, bit_data, 
wrapname, servername, servertype, serverversion, 
remote_typeschema, remote_typename, remote_meta_type, 
remote_lower_len, remote_upper_len, remote_lower_scale, remote_upper_scale, 
remote_s_opr_p, remote_bit_data, user_defined, create_time, definer, remarks 
from sysibm.systypemappings
