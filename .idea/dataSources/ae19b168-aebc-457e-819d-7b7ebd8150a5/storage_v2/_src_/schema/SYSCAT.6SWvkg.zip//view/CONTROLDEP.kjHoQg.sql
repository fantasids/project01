create or replace view syscat.controldep 
(dschema, dname, dtype, btype, bschema, bmodulename, bname, bmoduleid, 
bcolname ) 
as 
select 
a.dschema, a.dname, a.dtype, a.btype, a.bschema, m.modulename, a.bname, 
a.bmoduleid, cast(NULL as varchar(128)) 
from sysibm.sysdependencies a 
left outer join sysibm.sysmodules m on a.bmoduleid=m.moduleid 
where dtype = 'y' or dtype = '2' 
union all 
select 
b.dschema, 
b.dname, 
b.dtype, 
cast('C' as CHAR(1)), 
b.bschema, 
cast(NULL as varchar(128)), 
b.bname, 
cast(NULL as integer), 
b.bcolname 
from sysibm.syscoldependencies b 
where dtype = 'y' or dtype = '2' 

