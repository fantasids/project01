create or replace view syscat.securitylabelcomponents 
(compname, compid, comptype, numelements, create_time, remarks ) 
as (select 
a.compname, a.compid, a.comptype, a.numelements, a.create_time, c.remarks 
from sysibm.syssecuritylabelcomponents as a left outer join 
sysibm.syscomments as c on c.objecttype='d' and c.objectid=a.compid) 
