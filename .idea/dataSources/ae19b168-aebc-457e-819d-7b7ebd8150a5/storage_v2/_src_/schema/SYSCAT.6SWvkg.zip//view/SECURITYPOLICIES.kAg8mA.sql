create or replace view syscat.securitypolicies 
(secpolicyname, secpolicyid, numseclabelcomp, rwseclabelrel, 
notauthwriteseclabel, create_time, groupauths, 
roleauths, remarks ) 
as (select a.secpolicyname, a.secpolicyid, a.numseclabelcomp, a.rwseclabelrel, 
a.notauthwriteseclabel, a.create_time, a.groupauths, 
a.roleauths, c.remarks 
from sysibm.syssecuritypolicies as a left outer join sysibm.syscomments as c 
on c.objecttype='p' and c.objectid=a.secpolicyid)
