create or replace view syscat.coldist 
(tabschema, tabname, colname, type, seqno, colvalue, 
valcount, distcount) 
as select 
schema, tbname, name, type, seqno, colvalue, 
valcount, distcount 
from sysibm.syscoldist
