create or replace view syscat.events 
(evmonname, type, filter) 
as select 
name, type, filter 
from sysibm.sysevents
