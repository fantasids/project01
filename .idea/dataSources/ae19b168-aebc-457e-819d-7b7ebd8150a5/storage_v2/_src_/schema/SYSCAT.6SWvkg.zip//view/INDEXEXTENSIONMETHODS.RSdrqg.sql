create or replace view syscat.indexextensionmethods 
(methodname, methodid, ieschema, iename, rangefuncschema, 
rangefuncname, rangespecificname, filterfuncschema, 
filterfuncname, filterspecificname, remarks) 
as select 
methodname, methodid, ieschema, iename, rtfuncschema, 
rtfuncname, rtspecificname, cwfuncschema, cwfuncname, 
cwspecificname, remarks 
from sysibm.sysindexextensionmethods
