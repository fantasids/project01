create or replace view syscat.libraries 
(libschema, libname, owner, ownertype, lib_id, libversion_count, 
active_version, system_required, definer) 
as select 
libschema, libname, definer, definertype, lib_id, libversion_count, 
active_version, system_required, definer 
from sysibm.syslibraries 
