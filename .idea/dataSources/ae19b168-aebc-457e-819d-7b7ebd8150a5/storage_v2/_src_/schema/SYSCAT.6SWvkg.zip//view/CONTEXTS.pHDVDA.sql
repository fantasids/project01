create or replace view syscat.contexts 
(contextname , contextid, systemauthid, defaultcontextrole, 
create_time, alter_time, enabled, auditpolicyid, auditpolicyname, 
auditexceptionenabled, remarks) 
as select 
a.contextname , a.contextid, a.systemauthid,a.defaultcontextrole, 
a.create_time, a.alter_time, a.enabled, a.auditpolicyid, 
case when a.auditpolicyid is null then null 
else (select auditpolicyname from sysibm.sysauditpolicies aud 
where a.auditpolicyid = aud.auditpolicyid) 
end, 
a.auditexceptionenabled, b.remarks 
from sysibm.syscontexts a left outer join sysibm.syscomments b 
on a.contextid = b.objectid and b.objecttype = 'x'
