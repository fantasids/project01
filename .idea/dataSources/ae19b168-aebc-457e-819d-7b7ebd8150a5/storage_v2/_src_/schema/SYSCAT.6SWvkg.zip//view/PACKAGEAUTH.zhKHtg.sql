create or replace view syscat.packageauth 
(grantor, grantortype, grantee, granteetype, pkgschema, pkgname, 
controlauth, bindauth, executeauth) 
as select 
grantor, grantortype, grantee, granteetype, creator, name, 
controlauth, bindauth, executeauth 
from sysibm.sysplanauth
