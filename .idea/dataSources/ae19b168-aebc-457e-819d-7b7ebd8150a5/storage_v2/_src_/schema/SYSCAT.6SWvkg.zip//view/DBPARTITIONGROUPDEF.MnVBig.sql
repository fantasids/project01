create or replace view syscat.dbpartitiongroupdef 
(dbpgname, dbpartitionnum, in_use) 
as select 
ngname, nodenum, in_use 
from sysibm.sysnodegroupdef
