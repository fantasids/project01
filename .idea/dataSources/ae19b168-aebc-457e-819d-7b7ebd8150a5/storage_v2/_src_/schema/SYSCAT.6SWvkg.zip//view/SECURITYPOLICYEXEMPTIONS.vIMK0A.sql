create or replace view syscat.securitypolicyexemptions 
(grantor, grantee, granteetype, secpolicyid, accessrulename, 
accesstype, ordinal, actionallowed, grant_time) 
as (select grantor, grantee, granteetype, secpolicyid, 
accessrulename, accesstype, ordinal, actionallowed, grant_time 
from sysibm.syssecuritypolicyexemptions)
