create or replace view syscat.histogramtemplateuse 
(templatename, templateid, histogramtype, 
objecttype, objectid, serviceclassname, parentserviceclassname, 
workactionname, workactionsetname, workloadname) 
as select 
a.templatename, b.templateid, b.histogramtype, 
b.objecttype, b.objectid, 
case when b.objecttype in 'b' then 
c.serviceclassname 
else 
cast(null as varchar(128)) end, 
case when b.objecttype in 'b' then 
d.serviceclassname 
else 
cast(null as varchar(128)) end, 
case when b.objecttype in 'k' then 
e.actionname 
else 
cast(null as varchar(128)) end, 
case when b.objecttype in 'k' then 
f.actionsetname 
else 
cast(null as varchar(128)) end, 
case when b.objecttype in 'w' then 
g.workloadname 
else 
cast(null as varchar(128)) end 
from sysibm.syshistogramtemplateuse as b 
left outer join sysibm.syshistogramtemplates as a 
on b.templateid = a.templateid 
left outer join sysibm.sysserviceclasses as c 
on c.serviceclassid = b.objectid 
left outer join sysibm.sysserviceclasses as d 
on c.parentid = d.serviceclassid 
left outer join sysibm.sysworkactions as e 
on e.actionid = b.objectid 
left outer join sysibm.sysworkactionsets as f 
on e.actionsetid = f.actionsetid 
left outer join sysibm.sysworkloads as g 
on g.workloadid = b.objectid 
