create or replace view syscat.funcmappings 
(function_mapping, funcschema, funcname, funcid, 
specificname, owner, ownertype, wrapname, servername, servertype, 
serverversion, create_time, definer, remarks) 
as select 
function_mapping, funcschema, funcname, funcid, 
specificname, definer, definertype, wrapname, servername, servertype, 
serverversion, create_time, definer, remarks 
from sysibm.sysfuncmappings
