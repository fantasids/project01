create or replace view syscat.views 
(viewschema, viewname, owner, ownertype, seqno, viewcheck, readonly, 
valid, qualifier, func_path, text, definer, envstringunits) 
as select 
creator, name, definer, definertype, 1, check, readonly, 
valid, qualifier, func_path, text, definer, 
cast(case 
when stringunits = 'S' then 'SYSTEM' 
when stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)) 
from sysibm.sysviews
