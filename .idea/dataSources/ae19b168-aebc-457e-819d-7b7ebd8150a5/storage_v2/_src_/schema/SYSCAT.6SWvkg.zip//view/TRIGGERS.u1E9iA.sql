create or replace view syscat.triggers 
(trigschema, trigname, owner, ownertype, tabschema, tabname, 
trigtime, trigevent, eventupdate, eventdelete, eventinsert, granularity, 
valid, 
create_time, qualifier, func_path, text, 
last_regen_time, collationschema, 
collationname, collationschema_orderby, collationname_orderby, 
definer, secure, alter_time, debug_mode, 
enabled, envstringunits, remarks, lib_id, precompile_options, compile_options) 
as select 
schema, name, definer, definertype, tbcreator, tbname, 
trigtime, cast (case trigevent 
when '1' then 'M' 
when '2' then 'M' 
when '3' then 'M' 
when '4' then 'M' 
else trigevent end as char(1)), 
cast (case trigevent when '3' then 'N' 
when 'I' then 'N' 
when 'D' then 'N' 
else 'Y' end as char(1)), 
cast (case trigevent when '2' then 'N' 
when 'U' then 'N' 
when 'I' then 'N' 
else 'Y' end as char(1)), 
cast (case trigevent when '1' then 'N' 
when 'U' then 'N' 
when 'D' then 'N' 
else 'Y' end as char(1)), 
granularity, valid, 
create_time, qualifier, func_path, text, 
last_regen_time, 
coalesce(c1.collationschema, 'SYSIBM'), 
coalesce(c1.collationname, syscat.collationname(t.collationid)), 
coalesce(c2.collationschema, 'SYSIBM'), 
coalesce(c2.collationname, syscat.collationname(t.collationid_orderby)), 
definer, secure, alter_time, 
cast (case 
when t.debug_mode = ' ' then 'DISALLOW' 
when t.debug_mode = 'Y' then 'ALLOW' 
when t.debug_mode = 'N' then 'DISABLE' 
else t.debug_mode end as varchar(8)), 
enabled, 
cast(case 
when t.stringunits = 'S' then 'SYSTEM' 
when t.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
remarks, t.lib_id, c.precompile_options, c.compile_options 
from (sysibm.systriggers t 
left outer join sysibm.syscodeproperties as c 
on c.object_type = 'B' and 
t.lib_id = c.object_id and 
t.lib_id = c.lib_id) 
left outer join sysibm.syscollations as c1 
on t.collationid = c1.collationid 
left outer join sysibm.syscollations as c2 
on t.collationid_orderby = c2.collationid
