create or replace view syscat.routineauth 
(grantor, grantortype, grantee, granteetype, schema, specificname, 
typeschema, typename, routinetype, executeauth, grant_time) 
as select 
grantor, grantortype, grantee, granteetype, schema, specificname, 
typeschema, typename, routinetype, executeauth, grant_time 
from sysibm.sysroutineauth 
where schema not in ('SYSIBMINTERNAL') and 
not (grantee LIKE 'SYSROLE%' and granteetype='R')
