create or replace view syscat.librarybindfiles 
(libschema, libname, libversion, package_schema, 
package_name, package_version, bindfile_path) 
as select 
l.libschema, l.libname, b.libversion, b.package_schema, 
b.package_name, b.package_version, 
b.bindfile_path 
from sysibm.syslibrarybindfiles as b, 
sysibm.syslibraries as l 
where b.lib_id = l.lib_id
