create or replace view syscat.serviceclasses 
(serviceclassname, parentserviceclassname, serviceclassid, parentid, 
create_time, 
alter_time, enabled, agentpriority, prefetchpriority, maxdegree, 
bufferpoolpriority, inboundcorrelator, 
outboundcorrelator, collectaggactdata, collectaggreqdata, collectactdata, 
collectactpartition, collectreqmetrics, cpushares, cpusharetype, cpulimit, 
sortmemorypriority, sectionactualsoptions, collectagguowdata, remarks) 
as select 
a.serviceclassname, b.serviceclassname, a.serviceclassid, a.parentid, 
a.create_time, a.alter_time, a.enabled, a.agentpriority, 
a.prefetchpriority, a.maxdegree, a.bufferpoolpriority, 
a.inboundcorrelator, a.outboundcorrelator, a.collectaggactdata, 
a.collectaggreqdata, a.collectactdata, a.collectactpartition, 
a.collectreqmetrics, a.cpushares, a.cpusharetype, a.cpulimit, 
a.sortmemorypriority, a.sectionactualsoptions, a.collectagguowdata, c.remarks 
from ( sysibm.sysserviceclasses as a 
left outer join sysibm.sysserviceclasses as b 
on a.parentid = b.serviceclassid 
left outer join sysibm.syscomments as c 
on c.objecttype = 'b' and c.objectid = a.serviceclassid )
