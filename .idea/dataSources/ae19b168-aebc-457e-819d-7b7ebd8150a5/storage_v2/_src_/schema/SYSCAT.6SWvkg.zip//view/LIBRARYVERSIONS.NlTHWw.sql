create or replace view syscat.libraryversions 
(libschema, libname, libversion, owner, ownertype, versionid, 
create_time, version_path, bindfiles_count, definer ) 
as select 
l.libschema, l.libname, v.libversion, v.definer, v.definertype, 
cast('L' || digits (v.lib_id) || 'V' || digits (v.libversion) as varchar(22)), 
v.create_time, v.version_path, v.bindfiles_count, v.definer 
from sysibm.syslibraryversions as v, 
sysibm.syslibraries as l 
where v.lib_id = l.lib_id
