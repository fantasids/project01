create or replace view syscat.libraryauth 
(grantor, grantortype, grantee, granteetype, libschema, libname, 
alterauth, usageauth) 
as select 
grantor, grantortype, grantee, granteetype, libschema, libname, 
alterauth, usageauth 
from sysibm.syslibraryauth
