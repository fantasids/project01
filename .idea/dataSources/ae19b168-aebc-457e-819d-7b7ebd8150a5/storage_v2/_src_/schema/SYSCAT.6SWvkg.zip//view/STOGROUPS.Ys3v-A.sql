create or replace view syscat.stogroups 
(sgname, sgid, owner, create_time, defaultsg,  overhead, devicereadrate, 
writeoverhead, devicewriterate, datatag, cachingtier, remarks) 
as select 
a.sgname, a.sgid, a.owner, a.create_time, a.defaultsg, a.overhead, 
a.devicereadrate, a.writeoverhead, a.devicewriterate, a.datatag, 
cast( case 
when a.cachingtier = 0 then 'DISABLED' 
else 'ENABLED' 
end as varchar(8)), 
b.remarks 
from sysibm.sysstogroups a 
left outer join sysibm.syscomments b 
on a.sgid = b.objectid and b.objecttype = 't'
