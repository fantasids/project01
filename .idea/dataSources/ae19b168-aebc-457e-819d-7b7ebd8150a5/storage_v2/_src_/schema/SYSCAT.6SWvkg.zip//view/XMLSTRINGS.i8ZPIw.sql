create or replace view syscat.xmlstrings 
(stringid, string, string_utf8) 
as select 
stringid, 
substr(sysibm.xmlbit2char(string), 1, length(sysibm.xmlbit2char(string)) - 1), 
substr(string, 1, length(string) - 1) 
from sysibm.sysxmlstrings
