create or replace view syscat.references 
(constname, tabschema, tabname, owner, ownertype, refkeyname, 
reftabschema, reftabname, colcount, deleterule, updaterule, 
create_time, fk_colnames, pk_colnames, definer) 
as select 
relname, creator, tbname, definer, definertype, refkeyname, 
reftbcreator, reftbname, colcount, deleterule, updaterule, timestamp, 
coalesce(sysibm.deprecatedchar('-206', 'COLUMN', 
'SYSCAT.REFERENCES.FK_COLNAMES'), 
fkcolnames), 
coalesce(sysibm.deprecatedchar('-206', 'COLUMN', 
'SYSCAT.REFERENCES.PK_COLNAMES'), 
pkcolnames), 
definer 
from sysibm.sysrels
