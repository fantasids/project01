create or replace view syscat.bufferpoolexceptions 
(bufferpoolid, member, npages) 
as select 
bufferpoolid, nodenum, npages 
from sysibm.sysbufferpoolnodes
