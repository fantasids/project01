CREATE OR REPLACE view syscat.workclassattributes 
(workclassname, workclasssetname, workclassid, workclasssetid, type, value1, 
value2, value3) 
as select 
b.workclassname, c.workclasssetname, a.workclassid, c.workclasssetid, 
cast (case a.typeid 
when 1 then 'WORK TYPE' 
when 2 then 'TIMERONCOST' 
when 3 then 'CARDINALITY' 
when 4 then 'DATA TAG' 
when 5 then 'ROUTINE SCHEMA' 
else 'UNKNOWN' end as varchar(30)), 
a.value1, a.value2, a.value3 
from sysibm.sysworkclassattributes as a left outer join sysibm.sysworkclasses 
as b on a.workclassid = b.workclassid 
left outer join sysibm.sysworkclasssets as c on 
b.workclasssetid = c.workclasssetid
