create or replace view syscat.collations 
(collationschema, collationname, sourcecollationschema, 
sourcecollationname, owner, ownertype, remarks) 
as select 
c.collationschema, c.collationname, 
cast('SYSIBM' as VARCHAR(128)), 
syscat.collationname(c.sourcecollationid), 
c.owner, c.ownertype, cmnt.remarks 
from sysibm.syscollations c left outer join sysibm.syscomments cmnt 
on cmnt.objecttype='c' and c.objectid = cmnt.objectid
