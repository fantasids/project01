create or replace view syscat.moduleauth 
(grantor, grantortype, grantee, granteetype, moduleid, 
moduleschema, modulename, executeauth) 
as select 
a.grantor, a.grantortype, a.grantee, a.granteetype, a.moduleid, 
m.moduleschema, m.modulename, a.executeauth 
from sysibm.sysmoduleauth a, sysibm.sysmodules m 
where a.moduleid = m.moduleid and 
not (a.grantee LIKE 'SYSROLE%' and a.granteetype='R')
