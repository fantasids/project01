create or replace view syscat.xsrobjects 
(objectid, objectschema, objectname, targetnamespace, 
schemalocation, objectinfo, objecttype, owner, ownertype, 
create_time, alter_time, status, decomposition, remarks) 
as select 
o.xsrobjectid, o.xsrobjectschema, o.xsrobjectname, 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where o.targetnamespaceid=stringid), 
(select substr(sysibm.xmlbit2char(string), 1, 
length(sysibm.xmlbit2char(string))-1) from sysibm.sysxmlstrings 
where o.schemalocationid=stringid), 
o.objectinfo, o.objecttype, o.owner, o.ownertype, o.create_time, 
o.alter_time, o.status, o.decomposition, c.remarks 
from sysibm.sysxsrobjects as o left outer join sysibm.syscomments as c 
on o.xsrobjectid=c.objectid and c.objecttype='Z'
