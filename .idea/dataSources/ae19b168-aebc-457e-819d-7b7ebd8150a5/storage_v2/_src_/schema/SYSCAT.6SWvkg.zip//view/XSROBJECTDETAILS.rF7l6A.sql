create or replace view syscat.xsrobjectdetails 
(objectid, objectschema, objectname, grammar, properties) 
as select 
o.xsrobjectid, o.xsrobjectschema, o.xsrobjectname, 
o.grammar, o.properties 
from sysibm.sysxsrobjects as o 
where o.objecttype='S'
