create or replace view syscat.hierarchies 
(metatype, sub_schema, sub_name, super_schema, 
super_name, root_schema, root_name) 
as select 
metatype, sub_schema, sub_name, super_schema, 
super_name, root_schema, root_name 
from sysibm.syshierarchies
