create or replace view syscat.coluse 
(tabschema, tabname, colname, dimension, colseq, type) 
as select 
tabschema, tabname, colname, dimension, colseq, type 
from sysibm.syscoluse
