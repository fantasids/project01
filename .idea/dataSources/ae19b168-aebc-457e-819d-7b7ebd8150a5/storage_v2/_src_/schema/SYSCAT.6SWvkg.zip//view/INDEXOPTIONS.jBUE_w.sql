create or replace view syscat.indexoptions 
(indschema, indname, option, setting) 
as select 
indschema, indname, option, setting 
from sysibm.sysindexoptions
