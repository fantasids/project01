create or replace view syscat.routineparms 
(routineschema, routinemodulename, routinename, routinemoduleid, 
specificname, parmname, rowtype, ordinal, typeschema, typemodulename, 
typename, locator, length, scale, typestringunits, stringunitslength, 
codepage, 
collationschema, collationname, 
cast_funcschema, cast_funcspecific, target_typeschema, target_typemodulename, 
target_typename, scope_tabschema, scope_tabname, 
transformgrpname, default, remarks) 
as select 
r.routineschema, m.modulename, r.routinename, r.routinemoduleid, 
r.specificname, rp.parmname, rp.rowtype, rp.ordinal, d.schema, 
mt.modulename, d.name, rp.locator, rp.length, 
CASE WHEN (rp.codepage=1208 or rp.codepage=1200) and rp.scale<>0 THEN 
CAST(0 as SMALLINT) 
ELSE rp.scale END, 
CASE WHEN rp.codepage=1208 and rp.scale=0 THEN CAST('OCTETS' as VARCHAR(11)) 
WHEN rp.codepage=1208 and rp.scale=4 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
WHEN rp.codepage=1200 and rp.scale=0 THEN CAST('CODEUNITS16' as 
VARCHAR(11)) 
WHEN rp.codepage=1200 and rp.scale=2 THEN CAST('CODEUNITS32' as 
VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) END, 
CASE WHEN (rp.codepage=1208 or rp.codepage=1200) and rp.scale=0 THEN rp.length 
WHEN (rp.codepage=1208 or rp.codepage=1200) and rp.scale<>0 THEN 
CAST(rp.length/rp.scale as INTEGER) 
ELSE CAST(NULL AS INTEGER) END, 
rp.codepage, 
case when rp.collationid is null then null 
else coalesce(c.collationschema, 'SYSIBM') end, 
case when rp.collationid is null then null 
else coalesce(c.collationname, syscat.collationname(rp.collationid)) end, 
rcast.routineschema, rcast.specificname, 
dtarget.schema, mtt.modulename, dtarget.name, rp.scope_tabschema, 
rp.scope_tabname, rp.transform_grpname, rp.default, 
rp.remarks 
from (((((sysibm.sysroutineparms as rp 
left outer join sysibm.sysroutines as r on rp.routine_id = r.routine_id) 
left outer join sysibm.sysdatatypes as d on rp.typeid = d.typeid) 
left outer join sysibm.sysroutines as rcast 
on rcast.routine_id = rp.cast_function_id) 
left outer join sysibm.sysdatatypes as dtarget 
on dtarget.typeid = rp.target_typeid) 
left outer join sysibm.syscollations as c 
on rp.collationid = c.collationid) 
left outer join sysibm.sysmodules m on r.routinemoduleid = m.moduleid 
left outer join sysibm.sysmodules mt on rp.typemoduleid = mt.moduleid 
left outer join sysibm.sysmodules mtt on 
rp.target_typemoduleid = mtt.moduleid 
where rp.routineschema not in ('SYSIBMINTERNAL') 

