create or replace view syscat.checks 
(constname, owner, ownertype, tabschema, tabname, create_time, 
qualifier, type, func_path, text, percentvalid, collationschema, 
collationname, collationschema_orderby, collationname_orderby, definer, 
envstringunits) 
as select 
name, definer, definertype, tbcreator, tbname, create_time, 
qualifier, type,  func_path, text, percentvalid, 
coalesce(c1.collationschema, 'SYSIBM'), 
coalesce(c1.collationname, syscat.collationname(x.collationid)), 
coalesce(c2.collationschema, 'SYSIBM'), 
coalesce(c2.collationname, syscat.collationname(x.collationid_orderby)), 
definer, 
cast(case 
when x.stringunits = 'S' then 'SYSTEM' 
when x.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)) 
from sysibm.syschecks x 
left outer join sysibm.syscollations as c1 
on x.collationid = c1.collationid 
left outer join sysibm.syscollations as c2 
on x.collationid_orderby = c2.collationid
