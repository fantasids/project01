create or replace view syscat.constdep 
(constname, tabschema, tabname, btype, bschema, bmodulename, bname, bmoduleid) 
as select 
dconstname, dtbcreator, dtbname, btype, bcreator, m.modulename, bname, 
bmoduleid 
from sysibm.sysconstdep left outer join sysibm.sysmodules m on 
bmoduleid=m.moduleid
