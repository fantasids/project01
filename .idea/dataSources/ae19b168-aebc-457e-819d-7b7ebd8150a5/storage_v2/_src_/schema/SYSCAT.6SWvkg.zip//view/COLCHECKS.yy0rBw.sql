create or replace view syscat.colchecks 
(constname, tabschema, tabname, colname, usage) 
as select 
constname,tbcreator, tbname, colname, usage 
from sysibm.syscolchecks
