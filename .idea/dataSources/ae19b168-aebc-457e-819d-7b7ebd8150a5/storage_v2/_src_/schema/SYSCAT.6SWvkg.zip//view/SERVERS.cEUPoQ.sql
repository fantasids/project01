create or replace view syscat.servers 
(wrapname, servername, servertype, serverversion, remarks) 
as select 
wrapname, servername, servertype, serverversion, remarks 
from sysibm.sysservers
