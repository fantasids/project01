create or replace view syscat.nodegroups 
(ngname, owner, ownertype, pmap_id, rebalance_pmap_id, create_time, 
definer, remarks) 
as select 
name, definer, definertype, pmap_id, rebalance_pmap_id, ctime, 
definer, remarks 
from sysibm.sysnodegroups
