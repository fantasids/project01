create or replace view syscat.audituse 
(auditpolicyname, auditpolicyid, objecttype, 
subobjecttype, objectschema, objectname, auditexceptionenabled) 
as select 
a.auditpolicyname, a.auditpolicyid, cast('x' as char(1)), 
cast(' ' as char(1)), cast (null as char(1)), b.contextname, 
b.auditexceptionenabled 
from sysibm.sysauditpolicies a, sysibm.syscontexts b 
where b.auditpolicyid is not null 
and a.auditpolicyid = b.auditpolicyid 
union all 
select a.auditpolicyname, a.auditpolicyid, c.objecttype, 
c.subobjecttype, cast (null as char(1)), c.objectname, 
c.auditexceptionenabled 
from sysibm.sysauditpolicies a, sysibm.sysaudituse c 
where a.auditpolicyid = c.auditpolicyid 
union all 
select a.auditpolicyname, a.auditpolicyid, 
cast('i' as char(1)), cast('R' as char(1)), cast (null as char(1)), 
d.rolename, d.auditexceptionenabled 
from sysibm.sysauditpolicies a, sysibm.sysroles d 
where d.auditpolicyid is not null 
and a.auditpolicyid = d.auditpolicyid 
union all 
select a.auditpolicyname, a.auditpolicyid, e.type, 
cast(' ' as char(1)), e.creator, e.name, e.auditexceptionenabled 
from sysibm.sysauditpolicies a, sysibm.systables e 
where e.auditpolicyid is not null 
and a.auditpolicyid = e.auditpolicyid 
union all 
select a.auditpolicyname, a.auditpolicyid, 
cast('?' as char(1)), cast(' ' as char(1)), 
cast(null as char(1)), f.name, f.auditexceptionenabled 
from sysibm.sysauditpolicies a, sysibm.sysschemata f 
where f.auditpolicyid is not null 
and a.auditpolicyid = f.auditpolicyid
