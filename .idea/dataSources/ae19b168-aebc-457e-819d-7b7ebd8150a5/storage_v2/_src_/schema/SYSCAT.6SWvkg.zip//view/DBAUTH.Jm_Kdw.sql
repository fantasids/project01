create or replace view syscat.dbauth 
(grantor, grantortype, grantee, granteetype, 
bindaddauth, connectauth, createtabauth, dbadmauth, 
externalroutineauth, implschemaauth, loadauth, 
nofenceauth, quiesceconnectauth, libraryadmauth, securityadmauth, 
sqladmauth, wlmadmauth, explainauth, dataaccessauth, accessctrlauth, 
createsecureauth) 
as select 
grantor, grantortype, grantee, granteetype, 
bindaddauth, connectauth, createtabauth, dbadmauth, 
externalroutineauth, implschemaauth, loadauth, 
nofenceauth, quiesceconnectauth, libraryadmauth, securityadmauth, 
sqladmauth, wlmadmauth, explainauth, dataaccessauth, accessctrlauth, 
createsecureauth 
from sysibm.sysdbauth
