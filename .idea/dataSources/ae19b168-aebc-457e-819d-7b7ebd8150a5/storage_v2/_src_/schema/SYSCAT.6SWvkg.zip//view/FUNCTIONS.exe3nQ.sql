create or replace view syscat.functions 
(funcschema, funcname, specificname, definer, funcid, 
return_type, origin, type, method, effect, parm_count, 
parm_signature, create_time, qualifier, with_func_access, 
type_preserving, variant, side_effects, fenced, nullcall, 
cast_function, assign_function, scratchpad, 
final_call, parallelizable, contains_sql, dbinfo, result_cols, 
language, implementation, class, jar_id, 
parm_style, source_schema, source_specific, ios_per_invoc, 
insts_per_invoc, ios_per_argbyte, insts_per_argbyte, 
percent_argbytes, initial_ios, initial_insts, cardinality, 
implemented, selectivity, overridden_funcid, 
subject_typeschema, subject_typename, func_path, body, 
remarks) 
as select 
a.routineschema, a.routinename, a.specificname, a.definer, a.routine_id, 
a.return_type, a.origin, a.function_type, 
CAST (CASE a.routinetype 
WHEN 'M' THEN 'Y' 
ELSE 'N' END AS CHAR(1)), 
a.methodeffect, a.parm_count, 
a.parm_signature, a.createdts, a.qualifier, a.with_func_access, 
CAST (CASE 
WHEN a.type_preserving = 'Y' 
THEN 'Y' 
ELSE 'N' 
END AS CHAR(1)), 
CAST (CASE a.deterministic 
WHEN 'Y' THEN 'N' 
WHEN 'N' THEN 'Y' 
ELSE ' ' END AS CHAR(1)), 
a.external_action, a.fenced, a.null_call, 
a.cast_function, a.assign_function, a.scratchpad, 
a.final_call, a.parallel, a.sql_data_access, a.dbinfo, a.result_cols, 
a.language, a.implementation, 
(SELECT pj.class FROM 
SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id), 
(SELECT pj.jar_id FROM 
SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id), 
a.parameter_style, a.sourceschema, a.sourcespecific, a.ios_per_invoc, 
a.insts_per_invoc, a.ios_per_argbyte, a.insts_per_argbyte, 
a.percent_argbytes, a.initial_ios, a.initial_insts, a.cardinality, 
a.methodimplemented, a.selectivity, a.overridden_methodid, 
a.subject_typeschema, a.subject_typename, a.func_path, a.text, 
a.remarks 
from sysibm.sysroutines as a 
where a.routinetype in ('F', 'M') 
and a.routineschema not in ('SYSIBMINTERNAL')
