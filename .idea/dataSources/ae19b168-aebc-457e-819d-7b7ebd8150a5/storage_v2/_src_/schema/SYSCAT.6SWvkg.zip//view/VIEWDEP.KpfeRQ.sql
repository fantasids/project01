create or replace view syscat.viewdep 
(viewschema, viewname, dtype, owner, btype, bschema, bmodulename, bname, 
bmoduleid, 
tabauth, definer) 
as select 
dcreator, dname, dtype, vcauthid, btype, bcreator, m.modulename, bname, 
bmoduleid, 
case when btype <> 'v' then tabauth else SMALLINT(0) end, vcauthid 
from sysibm.sysviewdep left outer join sysibm.sysmodules m on 
bmoduleid=m.moduleid
