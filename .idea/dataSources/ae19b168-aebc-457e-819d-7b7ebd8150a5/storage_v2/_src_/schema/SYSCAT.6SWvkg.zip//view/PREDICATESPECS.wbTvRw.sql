create or replace view syscat.predicatespecs 
(funcschema, funcname, specificname, funcid, specid, 
contextop, contextexp, filtertext) 
as select 
f.routineschema, f.routinename, f.specificname, p.funcid, p.specid, 
p.contextop, p.contextexp, CAST(p.filtertext as CLOB(32K)) 
from sysibm.sysroutines as f, 
sysibm.syspredicatespecs as p 
where f.routine_id=p.funcid 
and f.routinetype in ('F', 'M') 
and f.routineschema not in ('SYSIBMINTERNAL')
