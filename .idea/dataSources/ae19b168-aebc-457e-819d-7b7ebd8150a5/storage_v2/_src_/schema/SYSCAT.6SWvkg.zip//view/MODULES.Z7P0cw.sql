create or replace view syscat.modules 
(moduleschema, modulename, moduleid, dialect, owner, ownertype, moduletype, 
base_moduleschema, base_modulename, create_time, remarks) 
as select 
moduleschema, modulename, moduleid, 
CAST (CASE 
WHEN moduletype = 'P' THEN 'PL/SQL' 
WHEN moduletype = 'A' THEN ' ' 
ELSE 'DB2 SQL PL' 
END AS VARCHAR(10)), 
owner, ownertype, moduletype, base_moduleschema, base_modulename, create_time, 
r.remarks 
from 
sysibm.sysmodules left outer join sysibm.syscomments r 
on moduleid = r.objectid and r.objecttype = 'm'
