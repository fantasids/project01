CREATE OR REPLACE view syscat.workclasses 
(workclassname, workclasssetname, workclassid, workclasssetid, create_time, 
alter_time, evaluationorder) 
as select 
a.workclassname, b.workclasssetname, a.workclassid, a.workclasssetid, 
a.create_time, a.alter_time, a.evaluationorder 
from sysibm.sysworkclasses as a left outer join sysibm.sysworkclasssets as b 
on a.workclasssetid = b.workclasssetid
