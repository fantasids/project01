create or replace view syscat.procparms 
(procschema, procname, specificname, servername, ordinal, 
parmname, typeschema, typename, typeid, 
sourcetypeid, nulls, length, scale, 
parm_mode, codepage, dbcs_codepage, as_locator, 
target_typeschema, target_typename, 
scope_tabschema, scope_tabname) 
as select 
routineschema, routinename, specificname, cast(null as varchar(128)), ordinal, 
parmname, typeschema, typename, typeid, 
cast(null as smallint), cast ('Y' as char(1)), 
length, scale, 
CAST (CASE rowtype 
WHEN 'P' THEN 'IN' 
WHEN 'O' THEN 'OUT' 
ELSE 'INOUT' END AS VARCHAR(5)), 
codepage, cast(null as smallint), locator, target_typeschema, target_typename, 
scope_tabschema, scope_tabname 
from sysibm.sysroutineparms 
where routinetype in ('P') 
and routineschema not in ('SYSIBMINTERNAL')
