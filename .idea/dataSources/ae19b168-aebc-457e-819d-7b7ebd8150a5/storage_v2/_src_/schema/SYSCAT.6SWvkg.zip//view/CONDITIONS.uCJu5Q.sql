create or replace view syscat.conditions 
(condschema, condmodulename, condname, condid, condmoduleid, 
sqlstate, owner, ownertype, create_time, remarks) 
as select 
v.varschema, m.modulename, v.varname, v.varid, v.varmoduleid, 
CAST(substr(v.default,2,5) AS CHAR(5)), v.owner, v.ownertype, 
v.create_time, c.remarks 
from 
sysibm.sysvariables as v 
left outer join sysibm.sysdatatypes as d on v.typeid = d.typeid 
left outer join sysibm.sysmodules as m on v.varmoduleid = m.moduleid 
left outer join sysibm.syscomments as c 
on v.varid = c.objectid and c.objecttype = 'v' 
where d.schema = 'SYSPROC' and d.name = 'DB2SQLSTATE'
