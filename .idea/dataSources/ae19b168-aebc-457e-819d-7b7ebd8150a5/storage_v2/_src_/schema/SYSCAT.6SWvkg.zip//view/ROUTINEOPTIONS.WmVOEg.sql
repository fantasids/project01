create or replace view syscat.routineoptions 
(routineschema, routinename, specificname, option, setting) 
as select 
a.routineschema, a.routinename, a.specificname, b.option, b.setting 
from sysibm.sysroutines a , sysibm.sysroutineoptions b 
where a.routine_id = b.routineid 
and a.routineschema not in ('SYSIBMINTERNAL')
