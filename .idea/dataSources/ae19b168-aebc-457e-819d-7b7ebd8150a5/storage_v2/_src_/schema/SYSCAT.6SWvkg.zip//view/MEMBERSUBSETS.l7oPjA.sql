create or replace view syscat.membersubsets 
(subsetname, subsetid, create_time, alter_time, enabled, 
memberprioritybasis, inclusivesubset, alternateserver, 
catalogdatabasealias, remarks) 
as select 
m.subsetname, m.subsetid, m.create_time, m.alter_time, m.enabled, 
m.memberprioritybasis, m.inclusivesubset, m.alternateserver, 
m.catalogdatabasealias, m.remarks 
from sysibm.sysmembersubsets as m 
