create or replace view syscat.schemaauth 
(grantor, grantortype, grantee, granteetype, schemaname, alterinauth, 
createinauth, dropinauth) 
as select 
grantor, grantortype, grantee, granteetype, schemaname, alterinauth, 
createinauth, dropinauth 
from sysibm.sysschemaauth
