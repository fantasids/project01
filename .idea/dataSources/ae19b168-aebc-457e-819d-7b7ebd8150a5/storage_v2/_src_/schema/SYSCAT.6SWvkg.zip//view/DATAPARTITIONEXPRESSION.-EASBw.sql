create or replace view syscat.datapartitionexpression 
(tabschema, tabname, datapartitionkeyseq, datapartitionexpression, 
nullsfirst) 
as select 
tabschema, tabname, datapartitionkeyseq, datapartitionexpression, 
nullsfirst 
from sysibm.sysdatapartitionexpression
