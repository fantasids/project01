create or replace view syscat.fullhierarchies 
(metatype, sub_schema, sub_name, 
super_schema, super_name, 
root_schema, root_name) 
as 
(select metatype, sub_schema, sub_name, 
super_schema, super_name, 
root_schema, root_name 
from sysibm.syshierarchies) 
union all 
(select h.metatype, h.sub_schema, h.sub_name, 
f.super_schema, f.super_name, 
h.root_schema, h.root_name 
from syscat.fullhierarchies as f, 
sysibm.syshierarchies as h 
where f.sub_schema = h.super_schema 
and f.sub_name = h.super_name)
