create or replace view syscat.tabdep 
(tabschema, tabname, dtype, owner, ownertype, btype, bschema, 
bmodulename, bname, bmoduleid, tabauth, varauth, definer) 
as select 
dcreator, dname, dtype, vcauthid, vcauthidtype, btype, bcreator, 
m.modulename, bname, bmoduleid, 
case when btype <> 'v' then tabauth else SMALLINT(0) end, 
case when btype = 'v' then tabauth else SMALLINT(0) end, vcauthid 
from sysibm.sysviewdep left outer join sysibm.sysmodules m on 
bmoduleid=m.moduleid
