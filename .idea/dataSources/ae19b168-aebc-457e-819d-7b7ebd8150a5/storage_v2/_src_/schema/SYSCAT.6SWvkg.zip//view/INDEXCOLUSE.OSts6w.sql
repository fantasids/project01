create or replace view syscat.indexcoluse 
(indschema, indname, colname, colseq, colorder, collationschema, 
collationname, virtual, text) 
as select 
indschema, indname, colname, colseq, 
case when i.colorder <> 'V' THEN  i.colorder else cast ('A' as char(1)) end, 
case when i.collationid is null then null 
else coalesce(c.collationschema, 'SYSIBM') end, 
case when i.collationid is null then null 
else coalesce(c.collationname, syscat.collationname(i.collationid)) end, 
cast (case when i.colorder = 'V' then 'Y' 
when i.text is not null then 'S' 
else 'N' end as char(1)), 
text 
from sysibm.sysindexcoluse as i left outer join sysibm.syscollations as c 
on i.collationid = c.collationid
