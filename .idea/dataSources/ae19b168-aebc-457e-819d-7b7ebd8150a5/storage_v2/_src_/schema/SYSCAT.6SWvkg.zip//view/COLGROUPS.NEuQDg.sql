create or replace view syscat.colgroups 
(colgroupschema, colgroupname, colgroupid, colgroupcard, 
numfreq_values, numquantiles) 
as select 
colgroupschema, colgroupname, colgroupid, colgroupcard, 
numfreq_values, numquantiles 
from sysibm.syscolgroups
