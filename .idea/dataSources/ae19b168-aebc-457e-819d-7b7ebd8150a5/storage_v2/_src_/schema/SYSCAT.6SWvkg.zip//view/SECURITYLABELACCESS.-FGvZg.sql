create or replace view syscat.securitylabelaccess 
(grantor, grantee, granteetype, seclabelid, secpolicyid, 
accesstype, grant_time) 
as (select grantor, grantee, granteetype, seclabelid, 
secpolicyid, accesstype, grant_time 
from sysibm.syssecuritylabelaccess)
