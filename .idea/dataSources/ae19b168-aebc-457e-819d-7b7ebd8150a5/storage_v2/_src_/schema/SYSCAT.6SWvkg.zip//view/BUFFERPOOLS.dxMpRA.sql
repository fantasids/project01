create or replace view syscat.bufferpools 
(bpname, bufferpoolid, dbpgname, npages, pagesize, estore, 
numblockpages, blocksize, ngname) 
as select 
bpname, bufferpoolid, ngname, npages, pagesize, cast('N' as char(1)), 
numblockpages, blocksize, ngname 
from sysibm.sysbufferpools
