create or replace view syscat.datatypes 
(typeschema, typemodulename, typename, owner, ownertype, 
sourceschema, sourcemodulename, sourcename, 
metatype, typerules, typeid, typemoduleid, sourcetypeid, sourcemoduleid, 
published, length, scale, typestringunits, stringunitslength, codepage, 
collationschema, collationname, 
array_length, arrayindextypeschema, arrayindextypename, arrayindextypeid, 
arrayindextypelength, arrayindextype_stringunits, 
arrayindextype_stringunitslength, create_time, valid, attrcount, 
instantiable, with_func_access, final, inline_length, natural_inline_length, 
jarschema, jar_id, class, sqlj_representation, 
alter_time, definer, nulls, func_path, constraint_text, last_regen_time, 
envstringunits, remarks) 
as select 
d.schema, m.modulename, d.name, d.definer, d.definertype, 
d.sourceschema, m2.modulename, d.sourcetype, 
case when d.metatype='W' then 'T' else d.metatype end, 
case when d.metatype='W' then 'W' 
when d.metatype='T' then 'S' 
else ' ' end, 
d.typeid, d.typemoduleid, d.sourcetypeid, d.sourcemoduleid, 
d.published, d.length, 
CASE WHEN (d.codepage=1208 or d.codepage=1200) and d.scale<>0 then CAST(0 as 
SMALLINT) 
ELSE d.scale END, 
CASE WHEN d.codepage=1208 and d.scale=0 THEN CAST('OCTETS' as VARCHAR(11)) 
WHEN d.codepage=1208 and d.scale=4 THEN CAST('CODEUNITS32' as VARCHAR(11)) 
WHEN d.codepage=1200 and d.scale=0 THEN CAST('CODEUNITS16' as VARCHAR(11)) 
WHEN d.codepage=1200 and d.scale=2 THEN CAST('CODEUNITS32' as VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) END, 
CASE WHEN (d.codepage=1208 or d.codepage=1200) and d.scale=0 THEN d.length 
WHEN (d.codepage=1208 or d.codepage=1200) and d.scale<>0 THEN 
CAST(d.length/d.scale as INTEGER) 
ELSE CAST(NULL AS INTEGER) END, 
d.codepage, 
case when d.collationid is null then null 
else coalesce(c.collationschema, 'SYSIBM') end, 
case when d.collationid is null then null 
else coalesce(c.collationname, syscat.collationname(d.collationid)) end, 
case when d.metatype='A' then d.array_length else null end, 
case when d.metatype='L' then cast('SYSIBM' as varchar(128)) else null end, 
case when d.metatype='L' then 
(select dd.name from sysibm.sysdatatypes dd 
where dd.typeid = d.arrayindextypeid) else null end, 
d.arrayindextypeid, 
case when d.metatype='L' then d.array_length else null end, 
CASE WHEN d.metatype='L' and d.arrayindextypeid=56 and 
(select ddcp.codepage from sysibm.sysdatatypes ddcp 
where ddcp.typeid=56)=1208 THEN 
CASE WHEN d.arrayindextypescale=0 THEN CAST('OCTETS' as VARCHAR(11)) 
WHEN d.arrayindextypescale=4 THEN 
CAST('CODEUNITS32' as VARCHAR(11)) 
ELSE CAST(NULL AS VARCHAR(11)) 
END 
ELSE CAST(NULL AS VARCHAR(11)) 
END, 
CASE WHEN d.metatype='L' and d.arrayindextypeid=56 and 
(select ddcp.codepage from sysibm.sysdatatypes ddcp 
where ddcp.typeid=56)=1208 THEN 
CASE WHEN d.arrayindextypescale=0 THEN d.array_length 
WHEN d.arrayindextypescale=4 THEN 
CAST(d.array_length/d.arrayindextypescale as INTEGER) 
ELSE CAST(NULL AS INTEGER) 
END 
ELSE CAST(NULL AS INTEGER) 
END, 
d.create_time, d.valid, d.attrcount, d.instantiable, 
d.with_func_access, d.final, d.inline_length, d.natural_inline_length, 
d.jarschema, d.jar_id, d.class, d.sqlj_representation, 
case when d.constraint_text is not null then d.create_time else d.alter_time 
end, 
d.definer, nulls, func_path, constraint_text, d.alter_time, 
cast(case 
when d.stringunits = 'S' then 'SYSTEM' 
when d.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
d.remarks 
from sysibm.sysdatatypes as d left outer join sysibm.syscollations as c 
on d.collationid = c.collationid 
left outer join sysibm.sysmodules m on d.typemoduleid=m.moduleid 
left outer join sysibm.sysmodules m2 on d.sourcemoduleid = m2.moduleid
