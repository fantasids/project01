create or replace view syscat.indexauth 
(grantor, grantortype, grantee, granteetype, indschema, indname, 
controlauth) 
as select 
grantor, grantortype, grantee, granteetype, creator, name, 
controlauth 
from sysibm.sysindexauth
