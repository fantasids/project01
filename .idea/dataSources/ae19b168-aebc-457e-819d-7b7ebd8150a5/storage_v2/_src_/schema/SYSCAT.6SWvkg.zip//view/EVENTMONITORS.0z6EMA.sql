create or replace view syscat.eventmonitors 
(evmonname, owner, ownertype, target_type, target, maxfiles, 
maxfilesize, buffersize, io_mode, write_mode, autostart, 
dbpartitionnum, monscope, evmon_activates, nodenum, 
definer, versionnumber, member, remarks) 
as select 
name, definer, definertype, target_type, target, maxfiles, 
maxfilesize, buffersize, io_mode, write_mode, autostart, 
nodenum, monscope, evmon_activates, nodenum, 
definer, versionnumber, nodenum, remarks 
from sysibm.syseventmonitors
