create or replace view syscat.variableauth 
(grantor, grantortype, grantee, granteetype, 
varschema, varname, varid, readauth, writeauth) 
as select 
a.grantor, a.grantortype, a.grantee, a.granteetype, 
b.varschema, b.varname,  a.varid, a.readauth, a.writeauth 
from 
sysibm.sysvariableauth as a, sysibm.sysvariables as b 
where a.varid = b.varid and 
not (a.grantee LIKE 'SYSROLE%' and a.granteetype='R')
