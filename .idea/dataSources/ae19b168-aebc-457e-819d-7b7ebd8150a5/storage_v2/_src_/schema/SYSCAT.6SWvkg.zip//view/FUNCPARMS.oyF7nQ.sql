create or replace view syscat.funcparms 
(funcschema, funcname, specificname, rowtype, ordinal, 
parmname, typeschema, typename, length, scale, codepage, 
cast_funcid, as_locator, target_typeschema, 
target_typename, scope_tabschema, scope_tabname, 
transform_grpname) 
as select 
routineschema, routinename, specificname, rowtype, ordinal, 
parmname, typeschema, typename, length, scale, codepage, 
cast_function_id, locator, target_typeschema, 
target_typename, scope_tabschema, scope_tabname, 
transform_grpname 
from sysibm.sysroutineparms 
where routinetype in ('F', 'M') 
and routineschema not in ('SYSIBMINTERNAL')
