create or replace view syscat.bufferpooldbpartitions 
(bufferpoolid, dbpartitionnum, npages) 
as select 
bufferpoolid, nodenum, npages 
from sysibm.sysbufferpoolnodes
