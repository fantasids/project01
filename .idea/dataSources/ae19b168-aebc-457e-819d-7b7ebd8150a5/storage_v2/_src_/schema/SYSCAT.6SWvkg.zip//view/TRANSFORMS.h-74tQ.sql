create or replace view syscat.transforms 
(typeid, typeschema, typename, groupname, funcid, 
funcschema, funcname, specificname, transformtype, 
format, maxlength, origin, remarks) 
as select 
d.typeid, d.schema, d.name, t.groupname, f.routine_id, 
f.routineschema, f.routinename, f.specificname, cast('FROM SQL' as 
varchar(8)), 
t.fromsql_format, t.fromsql_length, t.origin, t.remarks 
from sysibm.systransforms as t, 
sysibm.sysdatatypes as d, 
sysibm.sysroutines as f 
where t.typeid = d.typeid 
and t.fromsql_funcid = f.routine_id 
and f.routinetype in ('F', 'M') 
and f.routineschema not in ('SYSIBMINTERNAL') 
union all 
select d.typeid, d.schema, d.name, t.groupname, 
f.routine_id, f.routineschema, f.routinename, f.specificname, 
cast('TO SQL' as varchar(8)), t.tosql_format, cast(NULL as integer), 
t.origin, t.remarks 
from sysibm.systransforms as t, 
sysibm.sysdatatypes as d, 
sysibm.sysroutines as f 
where t.typeid = d.typeid 
and t.tosql_funcid = f.routine_id 
and f.routinetype in ('F', 'M') 
and f.routineschema not in ('SYSIBMINTERNAL')
