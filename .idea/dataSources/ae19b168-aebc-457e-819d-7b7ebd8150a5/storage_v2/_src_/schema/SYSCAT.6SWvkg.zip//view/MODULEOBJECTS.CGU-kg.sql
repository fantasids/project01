create or replace view syscat.moduleobjects 
(objectschema, objectmodulename, objectname, 
objecttype, published, specificname, userdefined) 
as 
SELECT r.routineschema, m.modulename, r.routinename, 
cast(case r.routinetype 
when 'P' then 'PROCEDURE' 
when 'M' then 'METHOD' 
else 'FUNCTION' 
end as varchar(9)), 
r.published, r.specificname, 
cast (case r.origin 
when 'S' then 'N' 
when 'T' then 'N' 
else 'Y' 
end as char(1)) 
FROM sysibm.sysroutines as r, sysibm.sysmodules as m 
WHERE r.routinemoduleid = m.moduleid 
UNION ALL 
SELECT v.varschema, m.modulename, v.varname, 
cast('CONDITION' as varchar(9)), 
v.published, NULL, cast('Y' as char(1)) 
FROM sysibm.sysvariables as v, sysibm.sysdatatypes as d, sysibm.sysmodules 
as m 
WHERE v.typeid = d.typeid 
AND v.varmoduleid = m.moduleid 
AND d.schema = 'SYSPROC' and d.name = 'DB2SQLSTATE' 
UNION ALL 
SELECT v.varschema, m.modulename, v.varname, 
cast('VARIABLE' as varchar(9)), 
v.published, NULL, cast('Y' as char(1)) 
FROM sysibm.sysvariables as v,  sysibm.sysdatatypes as d, sysibm.sysmodules 
as m 
WHERE v.typeid = d.typeid 
AND v.varmoduleid = m.moduleid 
AND not(d.schema = 'SYSPROC' and d.name = 'DB2SQLSTATE') 
UNION ALL 
SELECT t.schema, m.modulename, t.name, 
cast('TYPE' as varchar(9)), 
t.published, NULL, cast('Y' as char(1)) 
FROM sysibm.sysdatatypes as t, sysibm.sysmodules as m 
WHERE t.typemoduleid = m.moduleid 

