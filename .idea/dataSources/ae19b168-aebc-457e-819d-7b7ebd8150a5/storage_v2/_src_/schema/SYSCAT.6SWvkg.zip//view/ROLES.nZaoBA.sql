create or replace view syscat.roles 
(rolename, roleid, create_time, auditpolicyid, 
auditpolicyname, auditexceptionenabled, remarks) 
as select 
a.rolename, a.roleid, a.create_time, a.auditpolicyid, 
case when a.auditpolicyid is null then null 
else (select auditpolicyname from sysibm.sysauditpolicies aud 
where a.auditpolicyid = aud.auditpolicyid) 
end, 
a.auditexceptionenabled, b.remarks 
from sysibm.sysroles as a left outer join sysibm.syscomments as b 
on a.roleid = b.objectid and b.objecttype='r' 
where a.rolename not LIKE 'SYSROLE%'
