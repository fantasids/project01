create or replace view syscat.datatypedep 
(typeschema, typemodulename, typename, typemoduleid, 
btype, bschema, bmodulename, bname, bmoduleid, tabauth) 
as select 
dschema, md.modulename, dname, dmoduleid, 
btype, bschema, mb.modulename, bname, bmoduleid, tabauth 
from 
sysibm.sysdependencies 
left outer join sysibm.sysmodules md on dmoduleid=md.moduleid 
left outer join sysibm.sysmodules mb on bmoduleid=mb.moduleid 
where dtype = 'R'
