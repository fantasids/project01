create or replace view syscat.statementtexts 
(textid, text) 
as select 
t.textid, t.text 
from sysibm.sysstatementtexts t
