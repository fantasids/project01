create or replace view syscat.controls 
(controlschema, controlname, owner, ownertype, tabschema, tabname, colname, 
controlid, controltype, enforced, implicit, enable, valid, ruletext, 
tabcorrelation, qualifier, func_path, collationschema, 
collationname, collationschema_orderby, collationname_orderby, 
create_time, alter_time, envstringunits, remarks) 
as select 
a.controlschema, a.controlname, a.owner, a.ownertype, a.tabschema, a.tabname, 
a.colname, a.controlid, a.controltype, a.enforced, 
a.implicit, a.enable, a.valid, a.ruletext, a.tabcorrelation, a.qualifier, 
a.func_path, 
coalesce(c1.collationschema, 'SYSIBM'), 
coalesce(c1.collationname, syscat.collationname(a.collationid)), 
coalesce(c2.collationschema, 'SYSIBM'), 
coalesce(c2.collationname, syscat.collationname(a.collationid_orderby)), 
a.create_time, a.alter_time, 
cast(case 
when a.stringunits = 'S' then 'SYSTEM' 
when a.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
b.remarks 
from sysibm.syscontrols a 
left outer join sysibm.syscomments b 
on a.controlid = b.objectid and (b.objecttype = 'y' or 
b.objecttype = '2') 
left outer join sysibm.syscollations as c1 
on a.collationid = c1.collationid 
left outer join sysibm.syscollations as c2 
on a.collationid_orderby = c2.collationid
