create or replace view syscat.packages 
(pkgschema, pkgname, boundby, boundbytype, owner, ownertype, default_schema, 
valid, 
unique_id, total_sect, format, isolation, concurrentaccessresolution, 
blocking, 
insert_buf, lang_level, func_path, queryopt, 
explain_level, explain_mode, explain_snapshot, sqlwarn, 
sqlmathwarn, create_time, explicit_bind_time, last_bind_time, alter_time, 
codepage, collationschema, collationname, 
collationschema_orderby, collationname_orderby, 
degree, multinode_plans, intra_parallel, validate, 
dynamicrules, sqlerror, refreshage, 
federated, transformgroup, reoptvar, 
os_ptr_size, pkgversion, 
staticreadonly, federated_asynchrony, 
anonblock, optprofileschema, optprofilename, 
pkgid, dbpartitionnum, 
definer, pkg_create_time, apreuse, extendedindicator, lastused, 
bustimesensitive, systimesensitive, 
keepdynamic, staticasdynamic, envstringunits, remarks, member) 
as select 
creator, name, boundby, boundbytype, boundby, boundbytype, default_schema, 
valid, 
unique_id, totalsect, format, isolation, concurrentaccessresolution, block, 
insert_buf, standards_level, func_path, queryopt, 
explain_level, explain_mode, explain_snapshot, sqlwarn, 
sqlmathwarn, pkg_create_time, explicit_bind_time, last_bind_time, alter_time, 
codepage, 
coalesce((select c1.collationschema from 
sysibm.syscollations as c1 
where p.collationid = c1.collationid), 
'SYSIBM'), 
coalesce((select c1.collationname from 
sysibm.syscollations as c1 
where p.collationid = c1.collationid), 
syscat.collationname(p.collationid)), 
coalesce((select c2.collationschema from 
sysibm.syscollations as c2 
where p.collationid_orderby = c2.collationid), 
'SYSIBM'), 
coalesce((select c2.collationname from 
sysibm.syscollations as c2 
where p.collationid_orderby = c2.collationid), 
syscat.collationname(p.collationid_orderby)), 
degree, multinode_plans, intra_parallel, validate, 
dynamicrules, sqlerror, refreshage, 
federated, transformgroup, reoptvar, 
os_ptr_size, pkgversion, 
staticreadonly, federated_asynchrony, 
anonblock, optprofileschema, optprofilename, 
pkgid, dbpartitionnum, 
boundby, pkg_create_time, apreuse, extendedindicator, lastused, 
bustimesensitive, systimesensitive, 
keepdynamic, staticasdynamic, 
cast(case 
when p.stringunits = 'S' then 'SYSTEM' 
when p.stringunits = '4' then 'CODEUNITS32' 
else ' ' end as varchar(11)), 
remarks, member 
from sysibm.sysplan p 
