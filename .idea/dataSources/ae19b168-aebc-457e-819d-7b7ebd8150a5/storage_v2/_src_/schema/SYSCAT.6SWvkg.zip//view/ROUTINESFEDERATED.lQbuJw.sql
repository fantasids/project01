create or replace view syscat.routinesfederated 
(routineschema, routinename, routinetype, owner, ownertype, 
specificname, routineid, 
parm_count, 
deterministic, external_action, 
sql_data_access, commit_on_return, 
result_sets, 
create_time, alter_time, qualifier, 
result_cols, 
codepage, last_regen_time, 
remote_procedure, remote_schema, servername, 
remote_package , remote_procedure_alter_time, remarks ) 
as select 
routineschema, routinename, routinetype, definer, definertype, 
specificname, routine_id, 
parm_count, 
deterministic, external_action, 
sql_data_access, commit_on_return, 
result_sets, 
createdts, alteredts, qualifier, 
result_cols,  codepage, 
last_regen_time, 
(select cast(setting as varchar(128)) from sysibm.sysroutineoptions 
where routine_id =routineid and option='REMOTE_PROCEDURE'), 
(select cast(setting as varchar(128)) from sysibm.sysroutineoptions 
where routine_id =routineid and option='REMOTE_SCHEMA') , 
(select cast(setting as varchar(128)) from sysibm.sysroutineoptions 
where routine_id =routineid and option='SERVER'), 
(select cast(setting as varchar(128)) from sysibm.sysroutineoptions 
where routine_id =routineid and option='REMOTE_PACKAGE'), 
(select cast(setting as varchar(128)) from sysibm.sysroutineoptions 
where routine_id =routineid and option='ALTERED_TIMESTAMP'), 
remarks 
from sysibm.sysroutines where origin ='F' 
and routineschema not in ('SYSIBMINTERNAL')
