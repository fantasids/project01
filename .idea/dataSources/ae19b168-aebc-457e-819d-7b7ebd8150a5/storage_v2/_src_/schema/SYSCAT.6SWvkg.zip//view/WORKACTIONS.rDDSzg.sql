create or replace view syscat.workactions 
(actionname, actionid, actionsetname, actionsetid, workclassname, 
workclassid, create_time, alter_time, enabled, actiontype, 
refobjectid, refobjecttype, sectionactualsoptions) 
as select 
a.actionname, a.actionid, b.actionsetname, a.actionsetid, c.workclassname, 
a.workclassid, a.create_time, a.alter_time, a.enabled, a.actiontype, 
a.refobjectid, 
cast(case when a.actiontype = 't' then 'THRESHOLD' 
when a.actiontype in ('m','n') then 'SERVICE CLASS' 
else null end as varchar(30)), a.sectionactualsoptions 
from sysibm.sysworkactions as a left outer join sysibm.sysworkactionsets as b 
on a.actionsetid = b.actionsetid 
left outer join sysibm.sysworkclasses as c 
on a.workclassid = c.workclassid 
