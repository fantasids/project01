create or replace view syscat.indexxmlpatterns 
(indschema, indname, pindname, pindid, typemodel, datatype, hashed, length, 
scale, patternid, pattern) 
as select 
indschema, indname, pindname, pindid, typemodel, datatype, hashed, length, 
scale, patternid, pattern 
from sysibm.sysindexxmlpatterns
