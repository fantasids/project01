ALTER MODULE SYSIBMADM.UTL_SMTP PUBLISH PROCEDURE WRITE_RAW_DATA(INOUT c UTL_SMTP.connection, IN data BLOB(15M))       SPECIFIC UTL_SMTP_WRITE_RAW_DATA       LANGUAGE SQL     BEGIN       DECLARE returnValue        INTEGER;       DECLARE tcpConn            UTL_TCP.connection;       DECLARE seqToLookFor       BLOB(5);       DECLARE seqToRelaceWith    BLOB(6);       DECLARE seqReplacedString  BLOB(20M);       DECLARE seqFirstThree      BLOB(3);             IF (c.private_state <> UTL_SMTP.STATE_OPEN_DATA_SENT) THEN         /* SIGNAL SQLSTATE '29277' SET MESSAGE_TEXT = 'Operation is invalid in WRITE_RAW_DATA'; */         CALL SYSIBMINTERNAL.SQLEML_RAISE_ERROR( -20518, 'WRITE_RAW_DATA' );       END IF;             CALL UTL_SMTP.imp_convertSmtpToTcpStruct(c, tcpConn, 'UTL_SMTP.WRITE_RAW_DATA');             SET seqReplacedString = data;             IF (LENGTH(data) > 2) THEN         SET seqFirstThree = LEFT(data, 3);         SET seqToLookFor = BLOB( '.' || CHR(13) || CHR(10) );                                            /* .
 */         IF (LOCATE(seqToLookFor, seqFirstThree) = 1) THEN           SET seqReplacedString = BLOB( '.' ) || data;                                                   /* ..
 */         ELSE           SET seqToLookFor = BLOB('.' || CHR(10));                                                     /* .
 */           IF (LOCATE(seqToLookFor, seqFirstThree) = 1) THEN           SET seqReplacedString = BLOB('.') || data;                                                 /* ..
 */           END IF;         END IF;               SET seqToLookFor = BLOB( CHR(10) || '.' || CHR(13) );                                            /* 
.
 */         SET seqToRelaceWith = BLOB( CHR(10) || '..' || CHR(13) );                                        /* 
..
 */         SET seqReplacedString = REPLACE(seqReplacedString, seqToLookFor, seqToRelaceWith);               SET seqToLookFor = BLOB( CHR(10) || '.' || CHR(10) );                                            /* 
.
 */         SET seqToRelaceWith = BLOB( CHR(10) || '..' || CHR(10) );                                        /* 
..
 */         SET seqReplacedString = REPLACE(seqReplacedString, seqToLookFor, seqToRelaceWith);       END IF;             CALL UTL_TCP.WRITE_RAW(tcpConn, seqReplacedString, returnValue);     END
