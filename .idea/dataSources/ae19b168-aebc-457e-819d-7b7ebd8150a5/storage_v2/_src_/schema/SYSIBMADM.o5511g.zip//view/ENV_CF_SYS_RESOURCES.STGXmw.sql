CREATE OR REPLACE VIEW SYSIBMADM.ENV_CF_SYS_RESOURCES  (name, value, datatype, unit, id) AS SELECT  name, value, datatype, unit, id FROM TABLE(SYSPROC.ENV_GET_CF_SYS_RESOURCES()) as t
