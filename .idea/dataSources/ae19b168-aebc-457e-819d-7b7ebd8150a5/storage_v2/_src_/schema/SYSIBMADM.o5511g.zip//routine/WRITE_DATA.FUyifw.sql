ALTER MODULE SYSIBMADM.UTL_SMTP PUBLISH PROCEDURE WRITE_DATA(INOUT c UTL_SMTP.connection, IN data VARCHAR(32000))       SPECIFIC UTL_SMTP_WRITE_DATA       LANGUAGE SQL     BEGIN       DECLARE returnValue        INTEGER;       DECLARE tcpConn            UTL_TCP.connection;       DECLARE strToLookFor       VARCHAR(5);       DECLARE strToRelaceWith    VARCHAR(6);       DECLARE strReplacedString  VARCHAR(32672);       DECLARE strFirstThree      VARCHAR(3);             IF (c.private_state <> UTL_SMTP.STATE_OPEN_DATA_SENT) THEN         /* SIGNAL SQLSTATE '29277' SET MESSAGE_TEXT = 'Operation is invalid in WRITE_DATA'; */         CALL SYSIBMINTERNAL.SQLEML_RAISE_ERROR( -20518, 'WRITE_DATA' );       END IF;             CALL UTL_SMTP.imp_convertSmtpToTcpStruct(c, tcpConn, 'UTL_SMTP.WRITE_DATA' );             SET strReplacedString = data;             IF (LENGTH(data) > 2) THEN         SET strFirstThree = LEFT(data, 3);         SET strToLookFor = '.' || CHR(13) || CHR(10);                                            /* .
 */         IF (LOCATE(strToLookFor, strFirstThree) = 1) THEN         SET strReplacedString = '.' || data;                                                   /* ..
 */         ELSE         SET strToLookFor = '.' || CHR(10);                                                     /* .
 */           IF (LOCATE(strToLookFor, strFirstThree) = 1) THEN           SET strReplacedString = '.' || data;                                                 /* ..
 */           END IF;         END IF;               SET strToLookFor = CHR(10) || '.' || CHR(13);                                            /* 
.
 */         SET strToRelaceWith = CHR(10) || '..' || CHR(13);                                        /* 
..
 */         SET strReplacedString = REPLACE(strReplacedString, strToLookFor, strToRelaceWith);               SET strToLookFor = CHR(10) || '.' || CHR(10);                                            /* 
.
 */         SET strToRelaceWith = CHR(10) || '..' || CHR(10);                                        /* 
..
 */         SET strReplacedString = REPLACE(strReplacedString, strToLookFor, strToRelaceWith);       END IF;             CALL UTL_TCP.WRITE_TEXT(tcpConn, strReplacedString, LENGTH(strReplacedString), returnValue);     END
