create or replace view sysstat.routines 
(routineschema, routinemodulename, routinename, routinetype, specificname, 
ios_per_invoc, insts_per_invoc, ios_per_argbyte, insts_per_argbyte, 
percent_argbytes, initial_ios, initial_insts, cardinality, selectivity) 
as select 
routineschema, 
(select modulename from sysibm.sysmodules where moduleid = routinemoduleid), 
routinename, routinetype, specificname, ios_per_invoc, 
insts_per_invoc, ios_per_argbyte, insts_per_argbyte, percent_argbytes, 
initial_ios, initial_insts, cardinality, selectivity 
from sysibm.sysroutines 
where 
routinemoduleid is null and 
(  routineschema = USER OR 
definer = USER OR 
routineschema not in ('SYSIBMINTERNAL') AND 
exists 
( 
select 1 
from sysibm.sysdbauth 
where grantee = USER and ( dbadmauth = 'Y' or sqladmauth = 'Y' ) 
) ) 

