create or replace view sysstat.indexes 
(indschema, indname, tabschema, tabname, colnames, nleaf, 
nlevels, firstkeycard, first2keycard, first3keycard, 
first4keycard, fullkeycard, clusterratio, clusterfactor, 
sequential_pages, density, page_fetch_pairs, 
numrids, numrids_deleted, num_empty_leafs, 
average_random_fetch_pages, average_random_pages, 
average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
avgpartition_clusterratio, avgpartition_clusterfactor, 
avgpartition_page_fetch_pairs, 
datapartition_clusterfactor, indcard, pctpagessaved, 
avgleafkeysize, avgnleafkeysize) 
as select 
creator, name, tbcreator, tbname, colnames, nleaf, 
nlevels, firstkeycard, first2keycard, first3keycard, 
first4keycard, fullkeycard, clusterratio, clusterfactor, 
sequential_pages, density, page_fetch_pairs, 
numrids, numrids_deleted, num_empty_leafs, 
average_random_fetch_pages, average_random_pages, 
average_sequence_gap, average_sequence_fetch_gap, 
average_sequence_pages, average_sequence_fetch_pages, 
avgpartition_clusterratio, avgpartition_clusterfactor, 
avgpartition_page_fetch_pairs, 
datapartition_clusterfactor, indcard, pctpagessaved, 
avgleafkeysize, avgnleafkeysize 
from sysibm.sysindexes X 
where x.entrytype <> 'H' 
and x.indextype <> 'XVIL' 
and (exists 
(select 1 
from sysibm.sysindexauth 
where creator = X.creator 
and name = X.name 
and grantee = USER 
and controlauth = 'Y' ) 
or exists 
(select 1 
from sysibm.sysdbauth 
where  grantee = USER 
and dataaccessauth = 'Y') 
or exists 
(select 1 from sysibm.sysindexauth XA, sysibm.sysindexxmlpatterns XP 
where X.name = XP.pindname 
and XA.name = XP.indname 
and XA.creator = XP.indschema 
and XA.grantee = USER 
and XA.controlauth = 'Y') 
) 

