create or replace view sysstat.colgroups 
(colgroupschema, colgroupname, colgroupid, colgroupcard, 
numfreq_values, numquantiles, numquantile) 
as select 
colgroupschema, colgroupname, colgroupid, colgroupcard, 
numfreq_values, numquantiles, numquantiles 
from sysibm.syscolgroups 

