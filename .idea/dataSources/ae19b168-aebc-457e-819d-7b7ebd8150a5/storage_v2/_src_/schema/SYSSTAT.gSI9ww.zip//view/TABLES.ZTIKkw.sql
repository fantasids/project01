create or replace view sysstat.tables 
(tabschema, tabname, card, npages, mpages, fpages, overflow, 
clustered, active_blocks, avgcompressedrowsize, avgrowcompressionratio, 
avgrowsize, pctrowscompressed, pctpagessaved, pctextendedrows ) 
as with getroles(level,drolename) as 
(select 1, u.rolename 
from table (select a.rolename from sysibm.sysroleauth as a 
where a.granteetype='U' and a.grantee=USER 
union all 
select a.rolename from sysibm.sysroleauth as a 
where a.granteetype='G' and a.grantee='PUBLIC') as u 
union all 
select level+1, x.rolename 
from getroles, 
table(select a.rolename from sysibm.sysroleauth as a 
where a.grantee=getroles.drolename and 
a.granteetype='R') as x 
where level<1000000), 
getdistroles(rolename) as (select distinct drolename from getroles) 
select 
creator, name, card, npages, mpages, fpages, overflow, 
clustered, active_blocks, avgcompressedrowsize, avgrowcompressionratio, 
avgrowsize, pctrowscompressed, pctpagessaved, pctextendedrows 
from sysibm.systables X 
where (X.type not in ('A', 'V', 'W', 'H', 'K') 
or (X.type = 'V' and substr(X.property, 13, 1) = 'Y')) 
and (exists 
(select 1 
from   sysibm.systabauth ta 
where  ta.tcreator = X.creator 
and    ta.ttname = X.name 
and    ta.controlauth = 'Y' 
and    (   (ta.granteetype = 'U' 
and ta.grantee = USER) 
or (ta.granteetype = 'G' 
and ta.grantee = 'PUBLIC') 
or (ta.granteetype = 'R' 
and ta.grantee in (select r.rolename 
from getdistroles r )))) 
or exists 
(select 1 
from   sysibm.sysdbauth da 
where  da.dataaccessauth = 'Y' 
and    (  (da.grantee = USER 
and da.granteetype = 'U') 
or (da.granteetype = 'R' 
and da.grantee in (select r.rolename 
from getdistroles r )))) 
or exists 
(select 1 
from   sysibm.systabauth ta2, sysibm.sysviewdep vd 
where  (X.type='V' and substr(X.property,19,1)='Y') 
and    vd.btype IN ('T', 'U') 
and    vd.dname = X.name 
and    vd.dcreator = X.creator 
and    ta2.ttname = vd.bname 
and    ta2.tcreator = vd.bcreator 
and    ta2.controlauth = 'Y' 
and    (   (ta2.granteetype = 'U' 
and ta2.grantee = USER) 
or (ta2.granteetype = 'G' 
and ta2.grantee = 'PUBLIC') 
or (ta2.granteetype = 'R' 
and ta2.grantee in (select r.rolename 
from getdistroles r ))))) 

