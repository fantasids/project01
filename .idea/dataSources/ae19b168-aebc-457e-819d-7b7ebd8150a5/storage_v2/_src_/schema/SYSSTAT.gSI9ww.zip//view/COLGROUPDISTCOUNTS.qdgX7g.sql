create or replace view sysstat.colgroupdistcounts 
(colgroupid, type, seqno, valcount, distcount) 
as select 
colgroupid, type, seqno, valcount, distcount 
from sysibm.syscolgroupdistcounts 

