create or replace view sysstat.coldist 
(tabschema, tabname, colname, type, seqno, colvalue, valcount, 
distcount) 
as select 
schema, tbname, name, type, seqno, colvalue, valcount, 
distcount 
from sysibm.syscoldist X 
where exists 
(select 1 from sysibm.systabauth 
where ttname = X.tbname 
and tcreator = X.schema 
and grantee = USER 
and granteetype = 'U' 
and controlauth = 'Y') 
or exists 
(select 1 from sysibm.sysdbauth 
where grantee = USER 
and granteetype = 'U' 
and dataaccessauth = 'Y') 
or exists 
(select 1 
from  sysibm.systabauth ta2, sysibm.sysviewdep vd 
where (select substr(Y.property,19,1) 
from   sysibm.systables y 
where  y.name = X.tbname 
and    y.creator = X.schema 
and    y.type='V')='Y' 
and    vd.btype IN ('T', 'U') 
and    vd.dname = X.tbname 
and    vd.dcreator = X.schema 
and    ta2.ttname = vd.bname 
and    ta2.tcreator = vd.bcreator 
and    ta2.controlauth = 'Y' 
and    (ta2.granteetype = 'U' 
and   ta2.grantee = USER) ) 

