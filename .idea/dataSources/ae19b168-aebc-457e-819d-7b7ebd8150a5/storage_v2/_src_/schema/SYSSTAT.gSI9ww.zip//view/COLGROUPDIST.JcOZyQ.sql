create or replace view sysstat.colgroupdist 
(colgroupid, type, ordinal, seqno, colvalue) 
as select 
colgroupid, type, ordinal, seqno, colvalue 
from sysibm.syscolgroupdist 

