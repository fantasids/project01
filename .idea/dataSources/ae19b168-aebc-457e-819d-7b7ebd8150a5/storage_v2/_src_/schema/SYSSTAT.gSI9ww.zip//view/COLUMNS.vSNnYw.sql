create or replace view sysstat.columns 
(tabschema, tabname, colname, colcard, high2key, low2key, 
avgcollen, numnulls, pctinlined, sub_count, sub_delim_length, 
avgcollenchar, pctencoded) 
as select 
tbcreator, tbname, name, colcard, high2key, low2key, 
avgcollen, numnulls, pctinlined, sub_count, sub_delim_length, 
avgcollenchar, pctencoded 
from sysibm.syscolumns X 
where( (source_tabschema = tbcreator and 
source_tabname = tbname) or 
(source_tabschema IS NULL and 
source_tabname IS NULL) ) 
and exists 
(select 1 
from   sysibm.systables 
where  name = X.tbname 
and    creator = X.tbcreator 
and    (type not in ('A', 'V', 'W', 'H', 'K') or 
(type = 'V' and substr(property, 13, 1) = 'Y') ) ) 
and (exists 
(select 1 from   sysibm.systabauth 
where  ttname = X.tbname 
and    tcreator = X.tbcreator 
and    controlauth = 'Y' 
and   ( (granteetype = 'U' 
and      grantee = USER) 
or      (granteetype = 'G' 
and      grantee = 'PUBLIC')) 
or exists 
(select 1 from   sysibm.sysdbauth 
where  grantee = USER 
and    dataaccessauth = 'Y') 
or exists 
(select 1 
from   sysibm.systabauth ta2, sysibm.sysviewdep vd 
where  (select substr(Y.property,19,1) 
from   sysibm.systables y 
where  y.name = X.tbname 
and    y.creator = X.tbcreator 
and    y.type='V')='Y' 
and    vd.btype IN ('T', 'U') 
and    vd.dname = X.tbname 
and    vd.dcreator = X.tbcreator 
and    ta2.ttname = vd.bname 
and    ta2.tcreator = vd.bcreator 
and    ta2.controlauth = 'Y' 
and    ( (ta2.granteetype = 'U' 
and       ta2.grantee = USER) 
or       (ta2.granteetype = 'G' 
and       ta2.grantee = 'PUBLIC'))))) 

