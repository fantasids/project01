create or replace view sysstat.functions 
(funcschema, funcname, specificname, ios_per_invoc, 
insts_per_invoc, ios_per_argbyte, insts_per_argbyte, 
percent_argbytes, initial_ios, initial_insts, 
cardinality, selectivity) 
as select 
routineschema, routinename, specificname, ios_per_invoc, 
insts_per_invoc, ios_per_argbyte, insts_per_argbyte, 
percent_argbytes, initial_ios, initial_insts, 
cardinality, selectivity 
from sysibm.sysroutines 
where 
routinemoduleid is null and 
( routinetype in ('F', 'M') and 
routineschema not in ('SYSIBMINTERNAL') and 
( routineschema = USER or 
EXISTS 
( select 1 
from sysibm.sysdbauth 
where grantee = USER and ( dbadmauth = 'Y' or sqladmauth ='Y' ) ) ) ) 

