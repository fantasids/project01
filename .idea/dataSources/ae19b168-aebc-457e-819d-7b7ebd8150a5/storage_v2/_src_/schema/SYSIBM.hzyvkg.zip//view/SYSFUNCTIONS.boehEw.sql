CREATE OR REPLACE view sysibm.sysfunctions 
(name, schema, definer, specific, parm_signature, function_id, 
return_type, origin, type, create_time, parm_count, variant, 
side_effects, fenced, nullcall, cast_function, assign_function, 
scratchpad, final_call,language, implementation, source_specific, 
source_schema, ios_per_invoc, insts_per_invoc, ios_per_argbyte, 
insts_per_argbyte, percent_argbytes, initial_ios, initial_insts, 
internal_prec1, internal_prec2, remarks, internal_desc, parallelizable, 
contains_sql, dbinfo, result_cols, body, cardinality, parm_style, 
method, implemented, effect, func_path, type_preserving, 
with_func_access, selectivity, overridden_funcid, subject_typeschema, 
subject_typename, qualifier, class, jar_id) 
as select 
a.routinename, a.routineschema, a.definer, a.specificname, 
a.parm_signature, a.routine_id, 
a.return_type, a.origin, a.function_type, a.createdts, a.parm_count, 
CAST 
(CASE a.deterministic 
WHEN 'Y' THEN 'N' 
WHEN 'N' THEN 'Y' 
ELSE ' ' END AS CHAR(1)), 
a.external_action, a.fenced, a.null_call, a.cast_function, 
a.assign_function, a.scratchpad, a.final_call, a.language, 
a.implementation, a.sourcespecific, a.sourceschema, a.ios_per_invoc, 
a.insts_per_invoc, a.ios_per_argbyte, a.insts_per_argbyte, 
a.percent_argbytes, a.initial_ios, a.initial_insts, a.internal_prec1, 
a.internal_prec2, a.remarks, a.internal_desc, a.parallel, 
a.sql_data_access, a.dbinfo, a.result_cols, a.text, a.cardinality, 
a.parameter_style, 
CAST 
(CASE a.routinetype 
WHEN 'M' THEN 'Y' ELSE 'N' END AS CHAR(1)), 
CASE 
WHEN a.routinetype = 'F' THEN 'Y' 
WHEN a.methodimplemented = 'N' AND a.with_func_access = 'N' THEN 'A' 
WHEN a.methodimplemented = 'Y' AND a.with_func_access = 'Y' THEN 'H' 
WHEN a.methodimplemented = 'Y' AND a.with_func_access = 'N' THEN 'M' 
ELSE ' ' 
END as methodimplemented, 
a.methodeffect, a.func_path, 
CAST 
(CASE 
WHEN a.type_preserving = 'Y' THEN 'Y' 
ELSE 'N' 
END AS CHAR(1)), 
CASE a.routinetype 
WHEN 'F' THEN 'Y' 
ELSE a.routinetype 
END as with_func_access, 
a.selectivity, a.overridden_methodid, 
a.subject_typeschema, a.subject_typename, a.qualifier, 
CASE 
WHEN a.language <> 'JAVA' THEN NULL 
ELSE 
(SELECT pj.class FROM 
SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id) 
END, 
CASE 
WHEN a.language <> 'JAVA' THEN NULL 
ELSE 
(SELECT pj.jar_id FROM 
SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id) 
END 
from sysibm.sysroutines as a 
where a.routinetype in ('F', 'M') 
and a.routineschema not in ('SYSIBMINTERNAL')
