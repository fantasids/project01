create or replace view sysibm.sysprocparms 
(procschema, procname, specificname, ordinal, parmname, 
typeschema, typename, length, scale, codepage, 
parm_mode, 
as_locator, target_typeschema, target_typename, 
scope_tabschema, scope_tabname, typeid, 
sourcetypeid, servername, dbcs_codepage, nulls) 
as select 
routineschema, routinename, specificname, ordinal, parmname, typeschema, 
typename, length, scale, codepage, 
CAST 
(CASE rowtype 
WHEN 'P' THEN 'IN' 
WHEN 'O' THEN 'OUT' 
ELSE 'INOUT' 
END AS VARCHAR(5)) , 
locator, target_typeschema, target_typename, scope_tabschema, 
scope_tabname, typeid, CAST(null as smallint),CAST(null as varchar(128)), 
CAST(null as smallint), CAST('Y' as char(1)) 
from sysibm.sysroutineparms 
where routinetype in ('P') 
and routineschema not in ('SYSIBMINTERNAL')
