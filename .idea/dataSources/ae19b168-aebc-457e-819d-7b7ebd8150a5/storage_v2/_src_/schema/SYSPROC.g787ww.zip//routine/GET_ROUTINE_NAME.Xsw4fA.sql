create or replace procedure SYSPROC.GET_ROUTINE_NAME
 (
  in lib_id integer,
  out type char(1),
  out schema varchar(128),
  out module varchar(128),
  out name varchar(128),
  out specific_name varchar(128)
 )
 specific GET_ROUTINE_NAME
 reads sql data
 begin
  declare continue handler for not found begin end;
  select *
  into type, schema, module, name, specific_name
  from (
        (select cast('T' as CHAR(1)), TRIGSCHEMA, NULL, TRIGNAME, NULL
         from syscat.triggers T
         where T.lib_id = GET_ROUTINE_NAME.lib_id
        )
        union all
        (select ROUTINETYPE, ROUTINESCHEMA, MODULENAME, ROUTINENAME, SPECIFICNAME
         from (syscat.routines R
               left outer join sysibm.sysmodules on routinemoduleid = moduleid)
         where R.lib_id = GET_ROUTINE_NAME.lib_id
        )
      );
 end
